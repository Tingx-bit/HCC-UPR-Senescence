# Bulk_09: USRS clinical nomogram performance
# Fig. 3C: calibration; Fig. 3D: time-dependent ROC;
# Fig. 3E: C-index comparison; Fig. S4A: decision curve analysis.
# IMPORTANT: OS.time must be measured in MONTHS (12/36/60 months).

library(survival)
library(rms)
library(timeROC)
library(ggplot2)
library(ggDCA)
library(boot)

input <- './results/Bulk_08_new/TCGA_Nomogram_Analysis_Data.csv'
outdir <- './results/Bulk_09_new'
if (!file.exists(input)) stop('Run Bulk_08 first; analysis data not found.')
if (dir.exists(outdir)) stop('Output folder already exists: ', outdir)
dir.create(outdir, recursive = TRUE)

rt <- read.csv(input, stringsAsFactors = FALSE)
rt$Gender <- factor(rt$Gender)
rt$Stage2 <- factor(rt$Stage2, levels = c('I', 'II', 'III/IV'))
rt$OS.time <- as.numeric(rt$OS.time)
rt$OS <- as.numeric(rt$OS)
if (!all(rt$OS %in% c(0, 1)) || any(rt$OS.time <= 0))
  stop('Check survival event coding and follow-up time.')
if (nrow(rt) < 50) stop('Unexpected sample count.')
cat('TCGA complete cases:', nrow(rt), '; OS events:', sum(rt$OS), '\n')

# 1. Same four-predictor model as Bulk_08 --------------------------
form <- Surv(OS.time, OS) ~ Age + Gender + Stage2 + riskscores
full_model <- coxph(form, data = rt, x = TRUE, y = TRUE)
rt$Nomogram_LP <- predict(full_model, type = 'lp')

# 2. Fig. 3D: time-dependent ROC (1, 3, 5 years) ------------------
roc <- timeROC(T = rt$OS.time, delta = rt$OS,
               marker = rt$Nomogram_LP, cause = 1,
               times = c(12, 36, 60), iid = TRUE)
roc_table <- data.frame(Time_months = c(12, 36, 60),
                        AUC = as.numeric(roc$AUC),
                        row.names = NULL)
write.csv(roc_table, file.path(outdir, 'Fig3D_TimeROC_AUC.csv'), row.names = FALSE)
pdf(file.path(outdir, 'Fig3D_Nomogram_TimeROC.pdf'), width = 6.5, height = 6)
plot(roc, time = 12, col = 'firebrick2', lwd = 2, title = FALSE)
plot(roc, time = 36, col = 'mediumseagreen', lwd = 2, add = TRUE)
plot(roc, time = 60, col = 'navy', lwd = 2, add = TRUE)
legend('bottomright', legend = paste0(c('1', '3', '5'), '-year AUC = ',
                                     sprintf('%.3f', roc_table$AUC)),
       col = c('firebrick2', 'mediumseagreen', 'navy'), lwd = 2, bty = 'n')
dev.off()

# 3. Fig. 3E: apparent C-index comparisons ------------------------
models <- list(
  Nomogram = form,
  USRS = Surv(OS.time, OS) ~ riskscores,
  Stage = Surv(OS.time, OS) ~ Stage2,
  Age = Surv(OS.time, OS) ~ Age,
  Sex = Surv(OS.time, OS) ~ Gender
)

set.seed(123)
cindex_results <- data.frame()
for (nm in names(models)) {
  f <- models[[nm]]
  fit <- coxph(f, data = rt)
  apparent <- as.numeric(concordance(fit)$concordance)
  b <- boot(rt, statistic = function(data, indices) {
    x <- data[indices, , drop = FALSE]
    mod <- try(coxph(f, data = x), silent = TRUE)
    if (inherits(mod, 'try-error')) return(NA_real_)
    as.numeric(concordance(mod)$concordance)
  }, R = 1000)
  ci <- quantile(b$t[, 1], c(0.025, 0.975), na.rm = TRUE)
  cindex_results <- rbind(cindex_results,
                          data.frame(Model = nm, C_index = apparent,
                                     CI_lower = unname(ci[1]),
                                     CI_upper = unname(ci[2])))
}
write.csv(cindex_results, file.path(outdir, 'Fig3E_Cindex_Comparison.csv'), row.names = FALSE)
p <- ggplot(cindex_results, aes(x = reorder(Model, C_index), y = C_index)) +
  geom_pointrange(aes(ymin = CI_lower, ymax = CI_upper)) +
  coord_flip() + theme_bw() +
  labs(x = NULL, y = 'Harrell C-index (bootstrap percentile 95% CI)')
ggsave(file.path(outdir, 'Fig3E_Cindex_Comparison.pdf'), p, width = 7, height = 4.5)

# 4. Bootstrap optimism correction: full nomogram -----------------
# Original final evaluation used rms::validate with B=1000.
units(rt$OS.time) <- 'Month'
dd <- datadist(rt)
options(datadist = 'dd')
fit_rms <- cph(form, data = rt, x = TRUE, y = TRUE, surv = TRUE)
set.seed(123)
val <- validate(fit_rms, method = 'boot', B = 1000, dxy = TRUE)
saveRDS(val, file.path(outdir, 'Bootstrap_Validation_1000.rds'))
internal_validation <- data.frame(
  Metric = c('Apparent C-index', 'Optimism-corrected C-index',
             'Optimism-corrected calibration slope'),
  Value = c((val['Dxy', 'index.orig'] + 1) / 2,
            (val['Dxy', 'index.corrected'] + 1) / 2,
            val['Slope', 'index.corrected'])
)
write.csv(internal_validation,
          file.path(outdir, 'Nomogram_Bootstrap_Internal_Validation.csv'),
          row.names = FALSE)

# 5. Fig. 3C: 12/36/60-month bootstrap calibration ----------------
cal_times <- c(12, 36, 60)
cal_list <- list()
pdf(file.path(outdir, 'Fig3C_Nomogram_Calibration.pdf'), width = 15, height = 5)
par(mfrow = c(1, 3))
for (i in seq_along(cal_times)) {
  t <- cal_times[i]
  f <- cph(form, data = rt, x = TRUE, y = TRUE, surv = TRUE, time.inc = t)
  set.seed(123)
  cal <- calibrate(f, cmethod = 'KM', method = 'boot', u = t,
                   m = 80, B = 1000)
  cal_list[[paste0(t, 'm')]] <- cal
  plot(cal, xlab = paste0('Predicted ', t / 12, '-year OS'),
       ylab = paste0('Observed ', t / 12, '-year OS'), subtitles = FALSE)
}
dev.off()
saveRDS(cal_list, file.path(outdir, 'Nomogram_Calibration_1000.rds'))

# 6. Fig. S4A: decision curves at 12/36/60 months -----------------
rs_model <- coxph(Surv(OS.time, OS) ~ riskscores, data = rt)
stage_model <- coxph(Surv(OS.time, OS) ~ Stage2, data = rt)
age_model <- coxph(Surv(OS.time, OS) ~ Age, data = rt)
sex_model <- coxph(Surv(OS.time, OS) ~ Gender, data = rt)
for (t in c(12, 36, 60)) {
  d <- ggDCA::dca(full_model, rs_model, stage_model, age_model, sex_model,
                  times = t)
  p <- ggplot(d) + theme_bw() +
    labs(title = paste0('Decision curve analysis: ', t / 12, '-year OS'),
         x = 'Threshold probability', y = 'Net benefit')
  ggsave(file.path(outdir, paste0('FigS4A_DCA_', t, 'months.pdf')),
         p, width = 8, height = 6)
}

options(datadist = NULL)
cat('Bulk_09 complete. Results:', outdir, '\n')
