# Bulk 11 | USRS and tumor microenvironment (Fig. S5A-D)
# Based on the original F5A.R and F5B.R workflows.
# Run from the project folder in RStudio. All paths are relative.

library(IOBR)
library(GSVA)
library(data.table)
library(dplyr)
library(tidyr)
library(ggplot2)
library(patchwork)
library(pheatmap)
library(rstatix)

# 1. Files and cohorts -------------------------------------------------------
input_file <- "new/hallmarker.RData"
gene_set_file <- "10 pathway.csv"
checkpoint_file <- "ICGs.txt"
output_dir <- "results/Bulk_11"

if (!file.exists(input_file)) stop("Missing: ", input_file)
if (!file.exists(gene_set_file)) stop("Missing: ", gene_set_file)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
load(input_file)

cohorts <- list(
  TCGA      = list(exp = exp_tcga,      clinical = cli_TCGA2,      arrays = FALSE),
  ICGC      = list(exp = exp_ICGC,      clinical = cli_ICGC2,      arrays = FALSE),
  GSE14520  = list(exp = exp_GSE14520,  clinical = cli_GSE145202,  arrays = TRUE),
  GSE116174 = list(exp = exp_GSE116174, clinical = cli_GSE1161742, arrays = TRUE)
)
cohort_names <- names(cohorts)
risk_colors <- c(High = "#E71D36", Low = "#1B3A57")

# Use the original USRS risk labels; do not silently redefine patient groups.
for (nm in cohort_names) {
  clinical <- cohorts[[nm]]$clinical
  if (!all(c("ID", "RS") %in% names(clinical))) {
    stop(nm, ": clinical data must contain ID and the original RS labels")
  }
  clinical$ID <- as.character(clinical$ID)
  clinical$RS <- as.character(clinical$RS)
  clinical$RS[clinical$RS == "High Risk"] <- "High"
  clinical$RS[clinical$RS == "Low Risk"] <- "Low"
  if (anyDuplicated(clinical$ID)) stop(nm, ": duplicate patient/sample IDs")
  if (any(!is.na(clinical$RS) & !clinical$RS %in% c("High", "Low"))) {
    stop(nm, ": RS must be High or Low")
  }
  cohorts[[nm]]$clinical <- clinical
}

# 2. Eight IOBR methods (original F5A) --------------------------------------
xcell_exclude <- c(
  "Adipocytes", "Astrocytes", "Chondrocytes", "Epithelial_cells",
  "Erythrocytes", "Hepatocytes", "Keratinocytes", "Melanocytes",
  "Mesangial_cells", "Myocytes", "Osteoblast", "Pericytes",
  "Preadipocytes", "Sebocytes", "Skeletal_muscle", "Smooth_muscle",
  "Neurons", "Megakaryocytes", "HSC", "CLP", "CMP", "GMP",
  "MEP", "MPP", "MSC", "pro_B-cells", "Platelets"
)

all_tme_tests <- list()
all_tme_scores <- list()

for (nm in cohort_names) {
  message("IOBR: ", nm)
  exp <- as.matrix(cohorts[[nm]]$exp)
  clinical <- cohorts[[nm]]$clinical
  arrays <- cohorts[[nm]]$arrays

  methods <- list(
    EPIC = deconvo_tme(eset = exp, method = "epic", arrays = arrays),
    MCPcounter = deconvo_tme(eset = exp, method = "mcpcounter"),
    xCell = deconvo_tme(eset = exp, method = "xcell", arrays = arrays),
    TIMER = deconvo_tme(eset = exp, method = "timer", group_list = rep("lihc", ncol(exp))),
    quanTIseq = deconvo_tme(eset = exp, method = "quantiseq", tumor = TRUE,
                           arrays = arrays, scale_mrna = TRUE),
    ESTIMATE = deconvo_tme(eset = exp, method = "estimate"),
    CIBERSORT = deconvo_tme(eset = exp, method = "cibersort", arrays = arrays, perm = 100),
    IPS = deconvo_tme(eset = exp, method = "ips", plot = FALSE)
  )

  # Keep the same CIBERSORT columns and xCell exclusions as the original F5A.
  methods$CIBERSORT <- methods$CIBERSORT[, seq_len(min(23, ncol(methods$CIBERSORT))), drop = FALSE]
  pattern <- paste0("^(", paste(xcell_exclude, collapse = "|"), ")_xCell$")
  methods$xCell <- methods$xCell[, !grepl(pattern, names(methods$xCell), ignore.case = TRUE), drop = FALSE]

  score_tables <- list()
  for (method in names(methods)) {
    tab <- as.data.frame(methods[[method]], check.names = FALSE)
    if (!"ID" %in% names(tab)) stop(nm, ": ID missing from ", method, " output")
    rownames(tab) <- as.character(tab$ID)
    tab$ID <- NULL
    tab <- tab[, vapply(tab, is.numeric, logical(1)), drop = FALSE]
    # Prevent duplicate method suffixes in feature names.
    suffix <- paste0("_", method)
    names(tab) <- ifelse(endsWith(tolower(names(tab)), tolower(suffix)),
                         names(tab), paste0(names(tab), suffix))
    score_tables[[method]] <- tab
  }

  ids <- Reduce(intersect, lapply(score_tables, rownames))
  ids <- intersect(ids, clinical$ID)
  if (length(ids) < 4) stop(nm, ": too few matching sample IDs")
  scores <- do.call(cbind, lapply(score_tables, function(x) x[ids, , drop = FALSE]))
  group <- clinical$RS[match(ids, clinical$ID)]
  all_tme_scores[[nm]] <- scores
  write.csv(data.frame(ID = ids, RS = group, scores, check.names = FALSE),
            file.path(output_dir, paste0(nm, "_IOBR_scores.csv")), row.names = FALSE)

  # One unadjusted two-sided Welch t-test for each feature (original F5A).
  tests <- lapply(colnames(scores), function(feature) {
    high <- scores[!is.na(group) & group == "High" & is.finite(scores[, feature]), feature]
    low <- scores[!is.na(group) & group == "Low" & is.finite(scores[, feature]), feature]
    if (length(high) < 2 || length(low) < 2 || length(unique(c(high, low))) < 2) return(NULL)
    data.frame(Dataset = nm, Feature = feature,
               P = tryCatch(t.test(high, low)$p.value, error = function(e) NA_real_),
               Mean_High = mean(high), Mean_Low = mean(low),
               Higher = ifelse(mean(high) > mean(low), "High", "Low"))
  })
  all_tme_tests[[nm]] <- bind_rows(tests)
}

tme_tests <- bind_rows(all_tme_tests) %>%
  mutate(Significance = ifelse(P < 0.05, "P < 0.05", "P >= 0.05"))
write.csv(tme_tests, file.path(output_dir, "FigS5A_IOBR_Welch_tests.csv"), row.names = FALSE)

# Fig. S5A: two-column dot plot; point size indicates unadjusted significance.
features <- sort(unique(tme_tests$Feature))
half <- ceiling(length(features) / 2)
tme_tests$Feature <- factor(tme_tests$Feature, levels = rev(features))
tme_tests$Panel <- ifelse(as.integer(tme_tests$Feature) <= half, "Left", "Right")
tme_tests$Dataset <- factor(tme_tests$Dataset, levels = cohort_names)

pA <- ggplot(tme_tests, aes(Dataset, Feature)) +
  geom_point(aes(color = Higher, size = Significance)) +
  facet_wrap(~Panel, scales = "free_y", nrow = 1) +
  scale_color_manual(values = risk_colors) +
  scale_size_manual(values = c("P < 0.05" = 3, "P >= 0.05" = 0.8)) +
  labs(x = NULL, y = NULL, color = "Higher mean", size = "Unadjusted P") +
  theme_minimal(base_size = 9) +
  theme(panel.grid = element_blank(), axis.text.x = element_text(angle = 45, hjust = 1),
        axis.text.y = element_text(size = 6), strip.text = element_blank())
ggsave(file.path(output_dir, "FigS5A_IOBR_dotplot.pdf"), pA,
       width = 13, height = max(11, half * 0.24), limitsize = FALSE)

# Fig. S5C: immune and stromal score heatmaps.
for (nm in cohort_names) {
  scores <- all_tme_scores[[nm]]
  clinical <- cohorts[[nm]]$clinical
  annotation <- data.frame(RS = clinical$RS[match(rownames(scores), clinical$ID)])
  rownames(annotation) <- rownames(scores)
  pdf(file.path(output_dir, paste0("FigS5C_", nm, "_heatmap.pdf")), 12, 10)
  pheatmap(t(scores), scale = "row", annotation_col = annotation,
           show_colnames = FALSE, fontsize_row = 5)
  dev.off()
}

# 3. Ten functional signatures (original F5B) ------------------------------
# The current GSVA implementation uses gsvaParam(), not ssGSEA.
raw_sets <- fread(gene_set_file, header = FALSE, fill = TRUE, data.table = FALSE)
gene_sets <- lapply(seq_len(nrow(raw_sets)), function(i) {
  genes <- as.character(unlist(raw_sets[i, -1], use.names = FALSE))
  unique(toupper(trimws(genes[!is.na(genes) & nzchar(trimws(genes))])))
})
names(gene_sets) <- trimws(as.character(raw_sets[[1]]))

all_functional <- list()
for (nm in cohort_names) {
  message("GSVA: ", nm)
  exp <- as.matrix(cohorts[[nm]]$exp)
  rownames(exp) <- toupper(rownames(exp))
  sets <- lapply(gene_sets, intersect, y = rownames(exp))
  sets <- sets[lengths(sets) > 0]
  scores <- t(GSVA::gsva(GSVA::gsvaParam(exp, geneSets = sets)))
  clinical <- cohorts[[nm]]$clinical
  ids <- intersect(rownames(scores), clinical$ID)
  if (!length(ids)) stop(nm, ": no sample IDs match functional scores")
  all_functional[[nm]] <- data.frame(
    ID = ids, Dataset = nm, RS = clinical$RS[match(ids, clinical$ID)],
    scores[ids, , drop = FALSE], check.names = FALSE
  ) %>% pivot_longer(-c(ID, Dataset, RS), names_to = "Pathway", values_to = "Score")
}

functional <- bind_rows(all_functional)
functional$Dataset <- factor(functional$Dataset, levels = cohort_names)
functional$RS <- factor(functional$RS, levels = c("High", "Low"))
write.csv(functional, file.path(output_dir, "FigS5B_GSVA_scores.csv"), row.names = FALSE)

# Original F5B: one Wilcoxon test per pathway and cohort.
# Report unadjusted exploratory P values (the old BH grouping did not adjust across pathways).
stats_tbl <- functional %>%
  group_by(Dataset, Pathway) %>%
  wilcox_test(Score ~ RS) %>%
  ungroup() %>%
  add_significance("p")
write.csv(stats_tbl, file.path(output_dir, "FigS5B_Wilcoxon_tests.csv"), row.names = FALSE)

means <- functional %>%
  group_by(Dataset, Pathway, RS) %>%
  summarise(Mean = mean(Score, na.rm = TRUE), .groups = "drop") %>%
  pivot_wider(names_from = RS, values_from = Mean) %>%
  mutate(Diff = High - Low)
write.csv(means, file.path(output_dir, "FigS5B_group_means.csv"), row.names = FALSE)

# Fig. S5B: mean-score dumbbell plot with Wilcoxon significance stars.
star_x <- means %>% group_by(Pathway) %>%
  summarise(x = max(c(High, Low), na.rm = TRUE) +
              0.12 * max(diff(range(c(High, Low), na.rm = TRUE)), 0.05),
            .groups = "drop")
plot_stats <- left_join(stats_tbl, star_x, by = "Pathway")
pB <- ggplot(means, aes(y = Dataset)) +
  geom_segment(aes(x = Low, xend = High, yend = Dataset), color = "grey80", linewidth = 1.5) +
  geom_point(aes(x = Low, color = "Low RS"), size = 3.5) +
  geom_point(aes(x = High, color = "High RS"), size = 3.5) +
  geom_text(aes(x = (Low + High) / 2, label = sprintf("%.2f", Diff)),
            vjust = -0.9, size = 3) +
  geom_text(data = plot_stats, aes(x = x, y = Dataset, label = p.signif),
            inherit.aes = FALSE, size = 3.5, fontface = "bold") +
  facet_wrap(~Pathway, ncol = 2, scales = "free_x") +
  scale_color_manual(values = c("High RS" = unname(risk_colors["High"]),
                                "Low RS" = unname(risk_colors["Low"])), name = NULL) +
  labs(x = "Mean GSVA score", y = NULL) +
  theme_classic(base_size = 11) +
  theme(strip.text = element_text(face = "bold"), legend.position = "top") +
  scale_x_continuous(expand = expansion(mult = c(0.1, 0.2)))
ggsave(file.path(output_dir, "FigS5B_functional_dumbbell.pdf"), pB, width = 10, height = 12)

# Optional original F5B view: violin and boxplots.
star_y <- functional %>% group_by(Pathway) %>%
  summarise(y = max(Score, na.rm = TRUE) +
              0.1 * diff(range(Score, na.rm = TRUE)), .groups = "drop")
violin_stats <- left_join(stats_tbl, star_y, by = "Pathway")
p_violin <- ggplot(functional, aes(Dataset, Score, fill = RS)) +
  geom_violin(position = position_dodge(0.8), width = 0.9, trim = FALSE, alpha = 0.8) +
  geom_boxplot(position = position_dodge(0.8), width = 0.12, outlier.shape = NA) +
  geom_text(data = violin_stats, aes(Dataset, y, label = p.signif),
            inherit.aes = FALSE, fontface = "bold", size = 3.5) +
  scale_fill_manual(values = risk_colors) +
  facet_wrap(~Pathway, ncol = 2, scales = "free_y") +
  theme_bw(base_size = 11) + labs(x = NULL, y = "GSVA score")
ggsave(file.path(output_dir, "FigS5B_functional_violin.pdf"), p_violin,
       width = 10, height = 12)

# 4. Immune-checkpoint genes in TCGA (retained from consolidated Bulk 11) ----
if (file.exists(checkpoint_file)) {
  exp <- as.matrix(cohorts$TCGA$exp)
  clinical <- cohorts$TCGA$clinical
  ids <- intersect(colnames(exp), clinical$ID)
  group <- clinical$RS[match(ids, clinical$ID)]
  genes <- intersect(unique(scan(checkpoint_file, what = "character", quiet = TRUE)),
                     rownames(exp))
  if (!length(genes)) stop("No checkpoint genes matched TCGA expression")
  checkpoint_tests <- bind_rows(lapply(genes, function(gene) {
    value <- log2(as.numeric(exp[gene, ids]) + 1)
    data.frame(Gene = gene, P = wilcox.test(value ~ group)$p.value,
               Mean_High = mean(value[group == "High"], na.rm = TRUE),
               Mean_Low = mean(value[group == "Low"], na.rm = TRUE))
  }))
  write.csv(checkpoint_tests, file.path(output_dir, "FigS5D_checkpoint_Wilcoxon.csv"),
            row.names = FALSE)
  selected <- checkpoint_tests$Gene[checkpoint_tests$P < 0.05]
  if (length(selected)) {
    plot_df <- data.frame(RS = group,
                          t(log2(exp[selected, ids, drop = FALSE] + 1)),
                          check.names = FALSE) %>%
      pivot_longer(-RS, names_to = "Gene", values_to = "Expression")
    pD <- ggplot(plot_df, aes(Gene, Expression, fill = RS)) +
      geom_boxplot() + scale_fill_manual(values = risk_colors) +
      theme_classic() + theme(axis.text.x = element_text(angle = 45, hjust = 1))
    ggsave(file.path(output_dir, "FigS5D_checkpoint_expression.pdf"), pD,
           width = 11, height = 5)
  }
}

message("Finished. Results saved in: ", output_dir)
