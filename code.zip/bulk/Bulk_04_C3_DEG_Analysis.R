# Bulk_04: C3 versus other NMF subtypes — differential expression (Fig. S3D)
# Source: F3(1).R, original limma analysis.


library(limma)
library(ggplot2)
library(ggrepel)

# 1. Read the historical K=4 classification and TCGA expression matrix ----
load('./newdat/F2/F2.RData')
# Expected historical objects: exp_tcga (genes x samples), cli_data_matched4
stopifnot(exists('exp_tcga'), exists('cli_data_matched4'))
stopifnot(all(c('ID', 'Cluster') %in% colnames(cli_data_matched4)))

outdir <- './results/Bulk_04_new'
if (dir.exists(outdir)) stop('Output directory already exists; do not overwrite: ', outdir)
dir.create(outdir, recursive = TRUE)

# 2. Align expression and clinical data -------------------------------
common_samples <- intersect(colnames(exp_tcga), as.character(cli_data_matched4$ID))
exp_use <- as.matrix(exp_tcga[, common_samples, drop = FALSE])
cli_use <- cli_data_matched4[match(common_samples, cli_data_matched4$ID), , drop = FALSE]
stopifnot(identical(colnames(exp_use), as.character(cli_use$ID)))

# C3 versus C1, C2 and C4; exclude samples without subtype labels.
cli_use <- cli_use[!is.na(cli_use$Cluster), , drop = FALSE]
exp_use <- exp_use[, cli_use$ID, drop = FALSE]
cluster_num <- sub('^C', '', as.character(cli_use$Cluster))
stopifnot(all(cluster_num %in% as.character(1:4)))
cli_use$Group_for_DE <- ifelse(cluster_num == '3', 'High', 'Low')
group <- factor(cli_use$Group_for_DE, levels = c('Low', 'High'))
print(table(group))
write.csv(data.frame(ID = cli_use$ID, Cluster = cluster_num,
                     Group = group),
          file.path(outdir, 'C3_vs_Others_Sample_Groups.csv'), row.names = FALSE)

# 3. limma differential expression — preserve original thresholds -------
design <- model.matrix(~0 + group)
colnames(design) <- levels(group)
fit <- lmFit(exp_use, design)
contrast <- makeContrasts(High - Low, levels = design)
fit2 <- eBayes(contrasts.fit(fit, contrast))
deg <- topTable(fit2, adjust.method = 'BH', number = Inf)
deg$gene <- rownames(deg)

deg$Change <- 'Not Sig'
deg$Change[deg$adj.P.Val < 0.05 & deg$logFC > 2] <- 'Up'
deg$Change[deg$adj.P.Val < 0.05 & deg$logFC < -2] <- 'Down'
deg_sig <- deg[deg$Change != 'Not Sig', , drop = FALSE]
deg_up <- deg[deg$Change == 'Up', , drop = FALSE]
deg_down <- deg[deg$Change == 'Down', , drop = FALSE]

write.csv(deg, file.path(outdir, 'C3_vs_Others_All_DEG.csv'), row.names = FALSE)
write.csv(deg_sig, file.path(outdir, 'C3_vs_Others_Significant_DEG.csv'), row.names = FALSE)
write.csv(deg_up, file.path(outdir, 'C3_vs_Others_Upregulated.csv'), row.names = FALSE)
write.csv(deg_down, file.path(outdir, 'C3_vs_Others_Downregulated.csv'), row.names = FALSE)
cat('All:', nrow(deg), 'Significant:', nrow(deg_sig),
    'Up:', nrow(deg_up), 'Down:', nrow(deg_down), '\n')

# 4. Volcano plot — Fig. S3D -------------------------------------------
# The original script labels up to 10 genes in each direction, ranked by P.
top_up <- head(deg_up$gene, 10)
top_down <- head(deg_down$gene, 10)
label_genes <- unique(c(top_up, top_down))

p_volcano <- ggplot(deg, aes(x = logFC, y = -log10(pmax(adj.P.Val, .Machine$double.xmin)),
                             color = Change)) +
  geom_point(size = 1.6, alpha = 0.8) +
  scale_color_manual(values = c('Up' = '#D73027', 'Down' = '#4575B4',
                                'Not Sig' = 'grey80')) +
  geom_vline(xintercept = c(-2, 2), linetype = 'dashed', linewidth = 0.5) +
  geom_hline(yintercept = -log10(0.05), linetype = 'dashed', linewidth = 0.5) +
  geom_text_repel(data = deg[deg$gene %in% label_genes, , drop = FALSE],
                  aes(label = gene), size = 3, max.overlaps = Inf) +
  labs(x = 'log2 Fold Change (C3 vs Others)',
       y = expression(-log[10]('adjusted P value')),
       title = 'Volcano plot: C3 vs Others') +
  theme_classic(base_size = 14) +
  theme(legend.title = element_blank(), legend.position = 'top',
        plot.title = element_text(hjust = 0.5))

ggsave(file.path(outdir, 'Fig_S3D_C3_vs_Others_Volcano.pdf'),
       p_volcano, width = 7, height = 6)

# The significant DEG table is the direct input for Bulk_05 (USRS construction).
# No Cox regression, gene selection or USRS scoring is performed in Bulk_04.
