# Bulk_12: USRS and TIDE-predicted immunotherapy response (Fig. S6A-D)


library(ggplot2)
library(dplyr)
library(ggpubr)
library(patchwork)

out_dir <- './results/Bulk_12_new'
if (dir.exists(out_dir)) stop('Output folder already exists: ', out_dir)

risk_files <- c(TCGA = './tcga/TCGA.risk.txt',
                ICGC = './ICGC/ICGC.risk.txt',
                GSE14520 = './GSE14520/GSE14520.risk.txt',
                GSE116174 = './GSE116174/GSE116174_risk.txt')
tide_files <- c(TCGA = './tcga/tide.csv',
                ICGC = './ICGC/ICGCtide.csv',
                GSE14520 = './GSE14520/gse14520tide.csv',
                GSE116174 = './GSE116174/GSE116174.TIDE.csv')

if (any(!file.exists(risk_files))) stop('Missing risk file(s): ', paste(risk_files[!file.exists(risk_files)], collapse=', '))
if (any(!file.exists(tide_files))) stop('Missing TIDE file(s): ', paste(tide_files[!file.exists(tide_files)], collapse=', '))
dir.create(out_dir, recursive = TRUE)

all_data <- list()
all_stats <- list()
colors <- c('Low Risk' = '#4393C3', 'High Risk' = '#D6604D')
response_colors <- c('Non-Responder' = '#D1D5DB', 'Responder' = '#1B90BE')

for (cohort in names(risk_files)) {
  risk <- read.delim(risk_files[[cohort]], check.names = FALSE, stringsAsFactors = FALSE)
  tide <- read.csv(tide_files[[cohort]], check.names = FALSE, stringsAsFactors = FALSE)
  if (!'ID' %in% names(risk)) {
    if (names(risk)[1] %in% c('X','V1','')) names(risk)[1] <- 'ID'
  }
  if (!'Patient' %in% names(tide)) stop(cohort, ': TIDE file lacks Patient column')
  if (!all(c('ID','riskscores','RS') %in% names(risk))) stop(cohort, ': risk file needs ID, riskscores, RS')
  if (!'TIDE' %in% names(tide)) stop(cohort, ': TIDE file lacks TIDE score')
  if (anyDuplicated(risk$ID) || anyDuplicated(tide$Patient)) stop(cohort, ': duplicate patient IDs')

  # Original risk grouping from the risk files is retained (not the fixed 0.6951 cutoff).
  # The historical plotting helper used the existing RS column when supplied.
  if ('Responder' %in% names(tide)) {
    response_raw <- tide$Responder
  } else if ('No benefits' %in% names(tide)) {
    response_raw <- !as.logical(tide[['No benefits']])
  } else {
    stop(cohort, ': TIDE file needs Responder or No benefits column')
  }
  response_raw <- tolower(trimws(as.character(response_raw)))
  response <- ifelse(response_raw %in% c('true','1','yes','responder'), 'Responder',
                     ifelse(response_raw %in% c('false','0','no','non-responder'), 'Non-Responder', NA_character_))
  tide$Response <- response

  dat <- merge(risk[, c('ID','riskscores','RS')],
               tide[, c('Patient','TIDE','Response')], by.x='ID', by.y='Patient')
  dat$riskscores <- as.numeric(dat$riskscores)
  dat$TIDE <- as.numeric(dat$TIDE)
  dat$RS <- ifelse(as.character(dat$RS) %in% c('High','High Risk'), 'High Risk',
                   ifelse(as.character(dat$RS) %in% c('Low','Low Risk'), 'Low Risk', NA_character_))
  dat <- dat[complete.cases(dat[, c('riskscores','TIDE','RS','Response')]), ]
  if (nrow(dat) < 4 || length(unique(dat$RS)) < 2 || length(unique(dat$Response)) < 2)
    stop(cohort, ': insufficient matched observations or groups')
  dat$RS <- factor(dat$RS, levels=c('Low Risk','High Risk'))
  dat$Response <- factor(dat$Response, levels=c('Non-Responder','Responder'))
  dat$Dataset <- cohort
  all_data[[cohort]] <- dat

  # S6A: TIDE score by USRS risk group; original Wilcoxon test.
  p_a <- ggplot(dat, aes(RS, TIDE, fill=RS)) +
    geom_violin(alpha=.55, trim=FALSE) + geom_boxplot(width=.15, outlier.shape=NA) +
    ggpubr::stat_compare_means(method='wilcox.test', label='p.format') +
    scale_fill_manual(values=colors) + theme_classic() +
    theme(legend.position='none') + labs(title=cohort, x=NULL, y='TIDE score')
  ggsave(file.path(out_dir, paste0(cohort, '_S6A_TIDE_by_Risk.pdf')), p_a, width=5, height=4.5)

  # S6B: Spearman correlation between continuous USRS and TIDE score.
  p_b <- ggplot(dat, aes(riskscores, TIDE)) +
    geom_point(alpha=.5, size=1.6) + geom_smooth(method='lm', se=TRUE) +
    ggpubr::stat_cor(method='spearman', label.x.npc='left', label.y.npc='top') +
    theme_classic() + labs(title=cohort, x='USRS', y='TIDE score')
  ggsave(file.path(out_dir, paste0(cohort, '_S6B_USRS_TIDE_Correlation.pdf')), p_b, width=5, height=4.5)

  # S6C: USRS distribution among predicted responders vs non-responders.
  p_c <- ggplot(dat, aes(Response, riskscores, fill=Response)) +
    geom_violin(alpha=.55, trim=FALSE) + geom_boxplot(width=.15, outlier.shape=NA) +
    ggpubr::stat_compare_means(method='wilcox.test', label='p.format') +
    scale_fill_manual(values=response_colors) + theme_classic() +
    theme(legend.position='none') + labs(title=cohort, x=NULL, y='USRS')
  ggsave(file.path(out_dir, paste0(cohort, '_S6C_USRS_by_Response.pdf')), p_c, width=5, height=4.5)

  # S6D: Proportions of predicted responders by original USRS risk groups.
  tab <- table(dat$RS, dat$Response)
  prop <- as.data.frame(tab)
  names(prop) <- c('RS','Response','n')
  prop <- prop %>% group_by(RS) %>% mutate(Percent=100*n/sum(n)) %>% ungroup()
  p_d <- ggplot(prop, aes(RS, n, fill=Response)) +
    geom_col(position='fill', width=.65, color='white') +
    scale_y_continuous(labels=function(x) paste0(round(x*100),'%')) +
    scale_fill_manual(values=response_colors) + theme_classic() +
    labs(title=cohort, x=NULL, y='Predicted response proportion', fill=NULL)
  ggsave(file.path(out_dir, paste0(cohort, '_S6D_Response_Proportion.pdf')), p_d, width=5, height=4.5)
  write.csv(prop, file.path(out_dir, paste0(cohort, '_Response_Counts.csv')), row.names=FALSE)

  cor_test <- cor.test(dat$riskscores, dat$TIDE, method='spearman', exact=FALSE)
  all_stats[[cohort]] <- data.frame(Dataset=cohort, N=nrow(dat),
    P_TIDE_by_RS=wilcox.test(TIDE ~ RS, data=dat)$p.value,
    Spearman_rho=unname(cor_test$estimate), P_Spearman=cor_test$p.value,
    P_USRS_by_Response=wilcox.test(riskscores ~ Response, data=dat)$p.value,
    P_Response_Proportion=fisher.test(tab)$p.value)
}

write.csv(do.call(rbind, all_stats), file.path(out_dir, 'Fig_S6_Statistics.csv'), row.names=FALSE)
write.csv(do.call(rbind, all_data), file.path(out_dir, 'Fig_S6_Matched_Data.csv'), row.names=FALSE)
message('Finished: ', out_dir)
