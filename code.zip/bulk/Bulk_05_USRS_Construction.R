# Bulk_05: USRS construction and subtype characterization (Fig. 2A-C, E, G)
# Based on F3(1).R. Run from E:/UPRS2.
# Input: historical expression/clinical objects + Bulk_04 differential expression.
# No original file is modified. Fig. 2C Metascape is external (export gene list only).

library(survival)
library(GSVA)
library(ggplot2)
library(ggpubr)
library(ggVennDiagram)
library(ComplexHeatmap)
library(circlize)
library(grid)

load('./newdat/F2/F2.RData')
stopifnot(exists('exp_tcga'), exists('cli_data_matched4'))
outdir <- './results/Bulk_05_new'
if (dir.exists(outdir)) stop('Output directory already exists: ', outdir)
dir.create(outdir, recursive = TRUE)

# 1. Read C3 vs others DEGs (Bulk_04) ------------------------------
deg <- read.csv('./results/Bulk_04_new/C3_vs_Others_Significant_DEG.csv', check.names = FALSE)
stopifnot(all(c('gene','logFC','adj.P.Val') %in% names(deg)))
deg <- deg[!is.na(deg$gene), ]
deg$gene <- toupper(deg$gene)
up_genes <- unique(deg$gene[deg$logFC > 2 & deg$adj.P.Val < 0.05])
down_genes <- unique(deg$gene[deg$logFC < -2 & deg$adj.P.Val < 0.05])

# 2. Univariate OS Cox on the same TCGA samples as DEG -------------
ids <- intersect(colnames(exp_tcga), as.character(cli_data_matched4$ID))
cli <- cli_data_matched4[match(ids, cli_data_matched4$ID), ]
cli <- cli[!is.na(cli$Cluster), ]
ids <- as.character(cli$ID)
expr <- as.matrix(exp_tcga[, ids, drop = FALSE])
rownames(expr) <- toupper(rownames(expr))
cox_genes <- intersect(unique(c(up_genes, down_genes)), rownames(expr))
cox_results <- list()
for (g in cox_genes) {
  dat <- data.frame(time = as.numeric(as.character(cli$OS.months)),
                    status = as.numeric(as.character(cli$OS.status)),
                    expression = as.numeric(expr[g, ]))
  dat <- dat[complete.cases(dat), ]
  if (nrow(dat) < 3 || sd(dat$expression) == 0 || sum(dat$status == 1) == 0) next
  fit <- try(coxph(Surv(time, status) ~ expression, data = dat), silent = TRUE)
  if (inherits(fit, 'try-error')) next
  sm <- summary(fit)
  cox_results[[g]] <- data.frame(Gene = g, HR = unname(sm$coef[1, 'exp(coef)']),
                                  Lower95 = unname(sm$conf.int[1, 'lower .95']),
                                  Upper95 = unname(sm$conf.int[1, 'upper .95']),
                                  P = unname(sm$coef[1, 'Pr(>|z|)']))
}
cox_df <- do.call(rbind, cox_results)
if (is.null(cox_df)) stop('No valid Cox results')
write.csv(cox_df, file.path(outdir, 'C3_DEG_Univariate_OS_Cox.csv'), row.names = FALSE)

# 3. Original gene selection: HR > 1.5 (risk); HR < 1 (protective)
poor_genes <- cox_df$Gene[cox_df$HR > 1.5 & cox_df$P < 0.05]
good_genes <- cox_df$Gene[cox_df$HR < 1 & cox_df$P < 0.05]
risk_genes <- intersect(up_genes, poor_genes)
protective_genes <- intersect(down_genes, good_genes)
writeLines(risk_genes, file.path(outdir, 'risk_genes.txt'))
writeLines(protective_genes, file.path(outdir, 'protective_genes.txt'))
cat('Risk:', paste(risk_genes, collapse = ', '), '\n')
cat('Protective:', paste(protective_genes, collapse = ', '), '\n')

# Fig. 2A: Venn diagrams -----------------------------------------
p1 <- ggVennDiagram(list('C3 upregulated' = up_genes, 'Poor prognosis' = poor_genes),
                    label_alpha = 0) + theme(legend.position = 'none')
p2 <- ggVennDiagram(list('C3 downregulated' = down_genes, 'Favorable prognosis' = good_genes),
                    label_alpha = 0) + theme(legend.position = 'none')
ggsave(file.path(outdir, 'Fig_2A_Risk_Venn.pdf'), p1, width = 5, height = 5)
ggsave(file.path(outdir, 'Fig_2A_Protective_Venn.pdf'), p2, width = 5, height = 5)

# Fig. 2B: Forest plot of selected model genes --------------------
model_genes <- c(risk_genes, protective_genes)
forest <- cox_df[match(model_genes, cox_df$Gene), ]
forest$Type <- ifelse(forest$Gene %in% risk_genes, 'Risk', 'Protective')
forest$Gene <- factor(forest$Gene, levels = rev(model_genes))
p3 <- ggplot(forest, aes(x = HR, y = Gene, color = Type)) +
  geom_vline(xintercept = 1, linetype = 'dashed') +
  geom_errorbarh(aes(xmin = Lower95, xmax = Upper95), height = 0.2) +
  geom_point(size = 2) + scale_x_log10() + theme_classic() +
  labs(x = 'Univariate OS hazard ratio (95% CI)', y = NULL)
ggsave(file.path(outdir, 'Fig_2B_Cox_Forest.pdf'), p3, width = 7, height = 6)
write.csv(forest, file.path(outdir, 'Fig_2B_Model_Gene_Cox.csv'), row.names = FALSE)

# Fig. 2C: gene list for the ORIGINAL Metascape analysis ----------
writeLines(model_genes, file.path(outdir, 'Fig_2C_Metascape_Input_Genes.txt'))
# Metascape enrichment figure must come from the original Metascape export.

# 4. USRS = GSVA enrichment(risk) - GSVA enrichment(protective) ----

if (length(risk_genes) == 0 || length(protective_genes) == 0) stop('Empty gene set')
all_expr <- as.matrix(exp_tcga)
rownames(all_expr) <- toupper(rownames(all_expr))
sets <- list(risk = intersect(risk_genes, rownames(all_expr)),
             protective = intersect(protective_genes, rownames(all_expr)))
param <- gsvaParam(all_expr, geneSets = sets)
es <- gsva(param)
USRS <- as.numeric(es['risk', ] - es['protective', ])
names(USRS) <- colnames(all_expr)
write.csv(data.frame(ID = names(USRS), USRS = USRS),
          file.path(outdir, 'TCGA_USRS_Scores.csv'), row.names = FALSE)

# Fig. 2E: USRS by NMF subtype -----------------------------------
cli$USRS <- USRS[match(cli$ID, names(USRS))]
cli$Cluster <- factor(sub('^C', '', as.character(cli$Cluster)),
                      levels = as.character(1:4), labels = paste0('C', 1:4))
plot_data <- cli[!is.na(cli$USRS) & !is.na(cli$Cluster), ]
print(kruskal.test(USRS ~ Cluster, data = plot_data))
comparisons <- list(c('C3','C1'), c('C3','C2'), c('C3','C4'))
p4 <- ggplot(plot_data, aes(Cluster, USRS, fill = Cluster)) +
  geom_violin(trim = FALSE) + geom_boxplot(width = 0.12, fill = 'white') +
  stat_compare_means(comparisons = comparisons, method = 'wilcox.test', label = 'p.format') +
  scale_fill_brewer(palette = 'Set1') + theme_classic() + theme(legend.position = 'none')
ggsave(file.path(outdir, 'Fig_2E_USRS_By_Subtype.pdf'), p4, width = 7, height = 6)

# Fig. 2G: model gene expression heatmap with clinical annotations
mat <- all_expr[intersect(model_genes, rownames(all_expr)), plot_data$ID, drop = FALSE]
mat_z <- t(scale(t(mat)))
mat_z[!is.finite(mat_z)] <- 0
ann <- data.frame(Cluster = plot_data$Cluster,
                  OS = as.factor(plot_data$OS.status),
                  Stage = as.factor(plot_data$Stage),
                  Grade = as.factor(plot_data$Grade),
                  Gender = as.factor(plot_data$Gender),
                  row.names = plot_data$ID)
if ('Age' %in% names(plot_data)) ann$Age <- as.numeric(as.character(plot_data$Age))
ord <- order(plot_data$Cluster)
mat_z <- mat_z[, ord, drop = FALSE]
ann <- ann[ord, , drop = FALSE]
row_groups <- factor(ifelse(rownames(mat_z) %in% risk_genes, 'Risk', 'Protective'),
                     levels = c('Risk','Protective'))
ha <- HeatmapAnnotation(df = ann, na_col = 'grey90')
ht <- Heatmap(mat_z, name = 'Z-score', top_annotation = ha,
              row_split = row_groups, column_split = ann$Cluster,
              cluster_column_slices = FALSE, show_column_names = FALSE,
              cluster_rows = FALSE, cluster_columns = TRUE)
pdf(file.path(outdir, 'Fig_2G_Model_Gene_Heatmap.pdf'), width = 11, height = 8)
draw(ht)
dev.off()

