# Bulk_10: USRS and Hallmark pathway correlations (Fig. 3G)
# Run from the project root. All input paths are relative.
# Required input: preprocessed four-cohort expression/clinical RData and MSigDB Hallmark GMT.

library(GSVA)
library(GSEABase)
library(pheatmap)
library(RColorBrewer)
save(cli_GSE116174,cli_GSE1161742,cli_GSE14520,cli_GSE145202,cli_ICGC,cli_ICGC2,cli_TCGA,cli_TCGA2,
     exp_GSE116174,exp_GSE14520,exp_ICGC,exp_tcga,file = "./new/hallmarker.RData")
input_rdata <- './new/hallmarker.RData'
gmt_file <- './h.all.v2024.1.Hs.symbols.gmt'
out_dir <- './results/Bulk_10_new'

if (!file.exists(input_rdata)) stop('Missing input: ', input_rdata)
if (!file.exists(gmt_file)) stop('Missing Hallmark GMT: ', gmt_file)
if (dir.exists(out_dir)) stop('Output directory already exists: ', out_dir)
dir.create(out_dir, recursive = TRUE)

load(input_rdata)
gene_sets <- GSEABase::getGmt(gmt_file)

datasets <- list(
  TCGA      = list(exp = exp_tcga,      cli = cli_TCGA2),
  ICGC      = list(exp = exp_ICGC,      cli = cli_ICGC2),
  GSE14520  = list(exp = exp_GSE14520,  cli = cli_GSE145202),
  GSE116174 = list(exp = exp_GSE116174, cli = cli_GSE1161742)
)

cor_results <- list()
p_results <- list()
sample_counts <- data.frame(Dataset = character(), N = integer())

for (dataset_name in names(datasets)) {
  cat('Processing:', dataset_name, '\n')
  exp_mat <- as.matrix(datasets[[dataset_name]]$exp)
  clinical <- datasets[[dataset_name]]$cli
  if (!all(c('ID', 'INScore') %in% colnames(clinical))) {
    stop('Clinical data need ID and INScore: ', dataset_name)
  }
  if (anyDuplicated(clinical$ID)) stop('Duplicate clinical IDs: ', dataset_name)
  if (anyDuplicated(colnames(exp_mat))) stop('Duplicate expression IDs: ', dataset_name)

  # Original method: GSVA (Gaussian kernel), not ssGSEA.
  param <- GSVA::gsvaParam(exp_mat, geneSets = gene_sets, kcdf = 'Gaussian')
  pathway_scores <- GSVA::gsva(param)
  common_ids <- intersect(colnames(pathway_scores), clinical$ID)
  risk <- clinical$INScore[match(common_ids, clinical$ID)]
  valid <- is.finite(risk)
  common_ids <- common_ids[valid]
  risk <- risk[valid]
  if (length(common_ids) < 4) stop('Too few matched samples: ', dataset_name)
  pathway_scores <- pathway_scores[, common_ids, drop = FALSE]

  rho <- numeric(nrow(pathway_scores))
  pval <- numeric(nrow(pathway_scores))
  for (i in seq_len(nrow(pathway_scores))) {
    test <- suppressWarnings(cor.test(as.numeric(pathway_scores[i, ]), risk,
                                      method = 'spearman', exact = FALSE))
    rho[i] <- unname(test$estimate)
    pval[i] <- test$p.value
  }
  names(rho) <- rownames(pathway_scores)
  names(pval) <- rownames(pathway_scores)
  cor_results[[dataset_name]] <- rho
  p_results[[dataset_name]] <- pval
  sample_counts <- rbind(sample_counts, data.frame(Dataset = dataset_name, N = length(common_ids)))
}

cor_mat <- do.call(rbind, cor_results)
p_mat <- do.call(rbind, p_results)
colnames(cor_mat) <- sub('^HALLMARK_', '', colnames(cor_mat))
colnames(p_mat) <- sub('^HALLMARK_', '', colnames(p_mat))

write.csv(cor_mat, file.path(out_dir, 'Fig3G_Hallmark_Spearman_Rho.csv'))
write.csv(p_mat, file.path(out_dir, 'Fig3G_Hallmark_Spearman_P.csv'))
write.csv(sample_counts, file.path(out_dir, 'Fig3G_Sample_Counts.csv'), row.names = FALSE)

# Preserve original figure convention: nominal P-value stars, no FDR correction.
star_mat <- matrix('', nrow = nrow(p_mat), ncol = ncol(p_mat),
                   dimnames = dimnames(p_mat))
star_mat[p_mat < 0.05] <- '*'
star_mat[p_mat < 0.01] <- '**'

pdf(file.path(out_dir, 'Fig3G_USRS_Hallmark_Heatmap.pdf'), width = 20, height = 5)
pheatmap::pheatmap(
  cor_mat,
  color = colorRampPalette(rev(RColorBrewer::brewer.pal(7, 'RdBu')))(100),
  display_numbers = star_mat,
  number_color = 'black', fontsize_number = 14,
  cellwidth = 20, cellheight = 20, border_color = 'white',
  cluster_cols = TRUE, cluster_rows = FALSE,
  angle_col = '45', fontsize_row = 10, fontsize_col = 8,
  main = 'Correlation: USRS vs Hallmark Pathways',
  legend_breaks = c(-1, -0.5, 0, 0.5, 1),
  legend_labels = c('-1', '-0.5', '0', '0.5', '1')
)
dev.off()

cat('Saved Fig. 3G and correlation tables to:', out_dir, '\n')
