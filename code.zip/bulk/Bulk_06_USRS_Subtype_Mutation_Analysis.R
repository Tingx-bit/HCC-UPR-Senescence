# Bulk_06: USRS subtype alluvial and mutation analysis (Fig. 2D, 2F)
# 
# 

library(ggplot2)
library(ggalluvial)
library(dplyr)
library(tidyr)

load('./newdat/F2/F2.RData')
stopifnot(exists('cli_data_matched4'))
outdir <- './results/Bulk_06_new'
if (dir.exists(outdir)) stop('Output directory already exists: ', outdir)
dir.create(outdir, recursive = TRUE)

# 1. Match NMF subtype, OS and USRS by patient ID ------------------
score <- read.csv('./results/Bulk_05_new/TCGA_USRS_Scores.csv', stringsAsFactors = FALSE)
stopifnot(all(c('ID', 'USRS') %in% names(score)))
cli <- cli_data_matched4
cli$ID <- substr(as.character(cli$ID), 1, 12)
score$ID <- substr(as.character(score$ID), 1, 12)
score <- score[!duplicated(score$ID), ]
cli$USRS <- score$USRS[match(cli$ID, score$ID)]
cli <- cli[!is.na(cli$USRS) & !is.na(cli$Cluster), ]
cli$Cluster <- factor(sub('^C', '', as.character(cli$Cluster)),
                      levels = as.character(1:4), labels = paste0('C', 1:4))
cli <- cli[!is.na(cli$Cluster), ]
# Median cutoff is calculated on the full available TCGA USRS cohort.
cutv <- median(score$USRS, na.rm = TRUE)
cli$RiskGroup <- factor(ifelse(cli$USRS > cutv, 'High', 'Low'), levels = c('High','Low'))
cli$OS_lab <- factor(ifelse(as.numeric(as.character(cli$OS.status)) == 1,
                            'Dead', 'Alive'), levels = c('Alive','Dead'))
write.csv(cli[, c('ID','Cluster','USRS','RiskGroup','OS_lab')],
          file.path(outdir, 'TCGA_USRS_Subtype_Groups.csv'), row.names = FALSE)
cat('USRS median cutoff:', cutv, '\n')

# Fig. 2D: three-layer alluvial plot -------------------------------
plot_cli <- cli[!is.na(cli$OS_lab), ]
dat <- as.data.frame(table(Cluster = plot_cli$Cluster,
                           RiskGroup = plot_cli$RiskGroup, OS_lab = plot_cli$OS_lab))
names(dat)[4] <- 'Freq'
dat <- dat[dat$Freq > 0, ]
lod <- ggalluvial::to_lodes_form(dat,
            axes = c('Cluster', 'RiskGroup', 'OS_lab'), id = 'alluvium')
fill_map <- c(C1='#E41A1C', C2='#377EB8', C3='#4DAF4A', C4='#984EA3',
              High='#D95F02', Low='#7570B3', Alive='#3288BD', Dead='#D53E4F')
p1 <- ggplot(lod, aes(x = x, y = Freq, alluvium = alluvium, stratum = stratum)) +
  geom_flow(aes(fill = stratum), width = 0.18, alpha = 0.80, knot.pos = 0.35) +
  geom_stratum(aes(fill = stratum), width = 0.5, color = 'grey35', linewidth = 0.3) +
  geom_text(stat = 'stratum', aes(label = after_stat(stratum)), size = 3.8, fontface = 'bold') +
  scale_x_discrete(limits = c('Cluster', 'RiskGroup', 'OS_lab'),
                   labels = c('Cluster', 'Risk', 'OS status'), expand = c(.04, .04)) +
  scale_fill_manual(values = fill_map, guide = 'none') +
  theme_minimal(base_size = 12) +
  theme(panel.grid = element_blank(), axis.title = element_blank(),
        axis.text.y = element_blank(), axis.ticks.y = element_blank(),
        axis.text.x = element_text(face = 'bold', color = 'black', size = 12))
ggsave(file.path(outdir, 'Fig_2D_Alluvial.pdf'), p1, width = 8, height = 7)
write.csv(dat, file.path(outdir, 'Fig_2D_Alluvial_Counts.csv'), row.names = FALSE)

# Fig. 2F: mutation frequency between USRS groups -----------------

maf_raw <- read.delim('./newdat/input.maf', header = TRUE, comment.char = '#',
                      stringsAsFactors = FALSE, fill = TRUE)
stopifnot(all(c('Tumor_Sample_Barcode', 'Hugo_Symbol') %in% names(maf_raw)))
maf_raw$Tumor_Sample_Barcode <- substr(maf_raw$Tumor_Sample_Barcode, 1, 12)
# Match the historical approach: patients represented in the MAF file.
comm <- intersect(unique(maf_raw$Tumor_Sample_Barcode), cli$ID)
mut_cli <- cli[cli$ID %in% comm, ]
high_ids <- unique(mut_cli$ID[mut_cli$RiskGroup == 'High'])
low_ids <- unique(mut_cli$ID[mut_cli$RiskGroup == 'Low'])
cat('MAF intersection:', length(comm), 'High:', length(high_ids),
    'Low:', length(low_ids), '\n')
if (length(high_ids) == 0 || length(low_ids) == 0) stop('Missing one risk group in MAF intersection')

# Original Fisher test, one row per gene; count unique mutated patients.
all_genes <- unique(maf_raw$Hugo_Symbol)
all_genes <- all_genes[!is.na(all_genes) & nzchar(all_genes)]
mutation_stats <- data.frame()
for (g in all_genes) {
  mutated <- unique(maf_raw$Tumor_Sample_Barcode[maf_raw$Hugo_Symbol == g])
  high_mut <- sum(high_ids %in% mutated)
  low_mut <- sum(low_ids %in% mutated)
  tab <- matrix(c(high_mut, length(high_ids) - high_mut,
                  low_mut, length(low_ids) - low_mut), nrow = 2)
  pv <- fisher.test(tab)$p.value
  mutation_stats <- rbind(mutation_stats, data.frame(
    Gene = g, HighRisk_Mutated = high_mut, HighRisk_Total = length(high_ids),
    LowRisk_Mutated = low_mut, LowRisk_Total = length(low_ids),
    HighRisk_Freq = 100 * high_mut / length(high_ids),
    LowRisk_Freq = 100 * low_mut / length(low_ids), p_value = pv))
}
write.csv(mutation_stats, file.path(outdir, 'Mutation_All_Genes.csv'), row.names = FALSE)
sig <- mutation_stats %>%
  filter(p_value < 0.05, HighRisk_Freq >= 5 | LowRisk_Freq >= 5) %>%
  arrange(p_value)
write.csv(sig, file.path(outdir, 'Mutation_Significant_Genes.csv'), row.names = FALSE)
# 
top9 <- head(sig, 9)
top6 <- top9 %>% mutate(diff = HighRisk_Freq - LowRisk_Freq) %>%
  arrange(desc(abs(diff))) %>% slice_head(n = 6)
write.csv(top6, file.path(outdir, 'Fig_2F_Top6_Mutation.csv'), row.names = FALSE)

if (nrow(top6) > 0) {
  plot_df <- top6 %>%
    select(Gene, HighRisk_Freq, LowRisk_Freq) %>%
    pivot_longer(c(HighRisk_Freq, LowRisk_Freq), names_to = 'Side', values_to = 'value') %>%
    mutate(Side = recode(Side, HighRisk_Freq = 'High Risk', LowRisk_Freq = 'Low Risk'),
           value_signed = ifelse(Side == 'High Risk', -value, value),
           Gene = factor(Gene, levels = rev(top6$Gene)))
  lim <- max(abs(plot_df$value_signed)) * 1.3
  p2 <- ggplot(plot_df, aes(Gene, value_signed, fill = Side)) +
    geom_col(width = 0.75) + coord_flip() +
    geom_hline(yintercept = 0, color = 'grey30') +
    geom_text(aes(label = sprintf('%.2f%%', abs(value_signed)),
                  hjust = ifelse(value_signed < 0, 1.05, -0.05)), size = 3) +
    scale_y_continuous(limits = c(-lim, lim), labels = function(x) abs(x)) +
    scale_fill_manual(values = c('High Risk' = 'red', 'Low Risk' = 'navy')) +
    labs(x = NULL, y = 'Mutation frequency (%)', fill = NULL) +
    theme_bw(base_size = 12) + theme(legend.position = 'top')
  ggsave(file.path(outdir, 'Fig_2F_Mutation_Frequency.pdf'), p2, width = 8, height = 5)
} else {
  warning('No genes met the original mutation screening criteria')
}

