# Bulk_08: Clinical Cox analysis and nomogram (Fig. 3A-B)


library(survival)
library(regplot)
library(ggplot2)

risk_file <- './data/tcga/TCGA.risk.txt'
clinical_file <- './data/tcga/cli_use_314.txt'
outdir <- './results/Bulk_08_new'

if (!file.exists(risk_file) || !file.exists(clinical_file))
  stop('TCGA risk or clinical input file is missing.')
if (dir.exists(outdir)) stop('Output directory already exists: ', outdir)
dir.create(outdir, recursive = TRUE)

# 1. Read and align patient-level data -----------------------------
risk <- read.table(risk_file, header = TRUE, sep = '\t', row.names = 1,
                   check.names = FALSE, stringsAsFactors = FALSE)
cli <- read.table(clinical_file, header = TRUE, sep = '\t', row.names = 1,
                  check.names = FALSE, stringsAsFactors = FALSE)

required_risk <- c('OS.time', 'OS', 'riskscores')
required_cli <- c('Age', 'Gender', 'Stage')
if (!all(required_risk %in% names(risk)) || !all(required_cli %in% names(cli)))
  stop('Missing required columns in original risk/clinical tables.')

common <- intersect(rownames(risk), rownames(cli))
if (anyDuplicated(common) || length(common) < 10) stop('Check unique patient IDs.')
risk <- risk[common, , drop = FALSE]
cli <- cli[common, , drop = FALSE]

rt <- data.frame(
  ID = common,
  OS.time = as.numeric(as.character(risk$OS.time)),
  OS = as.numeric(as.character(risk$OS)),
  Age = as.numeric(as.character(cli$Age)),
  Gender = factor(cli$Gender),
  Stage = as.character(cli$Stage),
  riskscores = as.numeric(as.character(risk$riskscores)),
  stringsAsFactors = FALSE
)

# Original F4 model: Stage I, II, and combined III/IV.
# Unrecognized or missing stages are excluded, not assigned to a group.
rt$Stage2 <- ifelse(rt$Stage %in% c('III', 'IV'), 'III/IV', rt$Stage)
rt$Stage2[!rt$Stage2 %in% c('I', 'II', 'III/IV')] <- NA
rt$Stage2 <- factor(rt$Stage2, levels = c('I', 'II', 'III/IV'))
rt <- rt[complete.cases(rt[, c('OS.time', 'OS', 'Age', 'Gender', 'Stage2', 'riskscores')]) &
           rt$OS.time > 0, , drop = FALSE]
rt$Gender <- droplevels(rt$Gender)
if (!all(rt$OS %in% c(0, 1))) stop('OS must be coded 0/1.')
if (nlevels(rt$Gender) < 2 || nlevels(droplevels(rt$Stage2)) < 2)
  stop('Not enough factor levels after complete-case filtering.')
if (nrow(rt) < 50) stop('Unexpectedly few complete cases; check clinical encoding.')

write.csv(rt, file.path(outdir, 'TCGA_Nomogram_Analysis_Data.csv'), row.names = FALSE)
cat('Patients:', nrow(rt), ' Events:', sum(rt$OS), '\n')
cat('Stage counts:\n'); print(table(rt$Stage2))
cat('Gender counts:\n'); print(table(rt$Gender))

# 2. Multivariable Cox regression (Fig. 3A) ------------------------
# Same predictors as the historical nomogram: age, sex, stage, USRS.
fit <- coxph(Surv(OS.time, OS) ~ Age + Gender + Stage2 + riskscores,
             data = rt, x = TRUE, y = TRUE)
print(summary(fit))

s <- summary(fit)
cox_table <- data.frame(
  Variable = rownames(s$coefficients),
  HR = s$conf.int[, 'exp(coef)'],
  Lower95CI = s$conf.int[, 'lower .95'],
  Upper95CI = s$conf.int[, 'upper .95'],
  P_value = s$coefficients[, 'Pr(>|z|)'],
  row.names = NULL
)
write.csv(cox_table, file.path(outdir, 'Fig3A_Multivariable_Cox.csv'), row.names = FALSE)
saveRDS(fit, file.path(outdir, 'TCGA_Clinical_USRS_Cox_Model.rds'))

# Forest plot: HR on its original log scale, reference line HR = 1.
p <- ggplot(cox_table, aes(x = reorder(Variable, HR), y = HR)) +
  geom_hline(yintercept = 1, linetype = 'dashed', color = 'grey50') +
  geom_pointrange(aes(ymin = Lower95CI, ymax = Upper95CI), size = 0.5) +
  coord_flip() + scale_y_log10() + theme_bw() +
  labs(x = NULL, y = 'Hazard ratio (95% CI)', title = 'Multivariable Cox regression')
ggsave(file.path(outdir, 'Fig3A_Multivariable_Cox_Forest.pdf'),
       p, width = 7, height = 5)

# 3. Nomogram (Fig. 3B) --------------------------------------------
# regplot shows 1-, 3-, and 5-year overall survival probabilities.
# Check that OS.time in the original risk file is in months before running.
pdf(file.path(outdir, 'Fig3B_USRS_Clinical_Nomogram.pdf'), width = 11, height = 7)
regplot(fit, clickable = FALSE, title = '', points = TRUE,
        droplines = TRUE, observation = rt[1, ], rank = 'sd',
        failtime = c(12, 36, 60), prfail = FALSE)
dev.off()

# Risk predictions are carried forward to Bulk_09 performance evaluation.
rt$Nomogram_LP <- predict(fit, newdata = rt, type = 'lp')
rt$Nomogram_RelativeRisk <- predict(fit, newdata = rt, type = 'risk')
write.csv(rt, file.path(outdir, 'TCGA_Nomogram_Predictions.csv'), row.names = FALSE)

# Note: No calibration, C-index or DCA is calculated here; see Bulk_09.
