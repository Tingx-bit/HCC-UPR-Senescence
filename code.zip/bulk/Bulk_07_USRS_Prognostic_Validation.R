# Bulk_07: USRS prognostic validation (Fig. 3F and Fig. S4B-D)
# Required files contain OS.time, OS and riskscores 
# OS.time must be in MONTHS; confirm units of each historical risk file before running.

library(survival)
library(survminer)
library(ggplot2)
library(timeROC)

outdir <- './results/Bulk_07_new'
if (dir.exists(outdir)) stop('Output directory already exists: ', outdir)
dir.create(outdir, recursive = TRUE)

# 1. Read the four original risk tables ----------------------------
files <- c(TCGA = './data/tcga/TCGA.risk.txt',
           ICGC = './data/ICGC/ICGC.risk.txt',
           GSE14520 = './data/GSE14520/GSE14520.risk.txt',
           GSE116174 = './data/GSE116174/GSE116174_risk.txt')
if (!all(file.exists(files))) stop('Missing input: ', paste(files[!file.exists(files)], collapse = ', '))


time_unit <- c(TCGA = 'months', ICGC = 'months',
               GSE14520 = 'months', GSE116174 = 'months')

cohorts <- list()
for (nm in names(files)) {
  d <- read.table(files[nm], header = TRUE, sep = '\t', check.names = FALSE,
                  row.names = 1, stringsAsFactors = FALSE)
  score_col <- intersect(c('riskscores', 'INScore', 'USRS'), names(d))[1]
  if (is.na(score_col) || !all(c('OS.time', 'OS') %in% names(d)))
    stop('Missing OS.time / OS / risk score in ', nm)
  d$ID <- rownames(d)
  d$riskscores <- as.numeric(as.character(d[[score_col]]))
  d$OS.time <- as.numeric(as.character(d$OS.time))
  d$OS <- as.numeric(as.character(d$OS))
  if (!all(na.omit(unique(d$OS)) %in% c(0, 1))) stop('OS must be 0/1 in ', nm)
  if (time_unit[nm] == 'days') d$OS.time <- d$OS.time / (365.25 / 12)
  if (time_unit[nm] == 'years') d$OS.time <- d$OS.time * 12
  d <- d[complete.cases(d[, c('OS.time', 'OS', 'riskscores')]) & d$OS.time > 0, ]
  if (nrow(d) < 10) stop('Too few complete patients in ', nm)
  cohorts[[nm]] <- d
}

# 2. Median-based risk groups (Fig. 3F and Fig. S4C) ---------------
summary_table <- data.frame()
for (nm in names(cohorts)) {
  d <- cohorts[[nm]]
  cutoff <- median(d$riskscores)
  d$RS <- factor(ifelse(d$riskscores > cutoff, 'High', 'Low'),
                 levels = c('Low', 'High'))
  cohorts[[nm]] <- d
  write.csv(d[, c('ID', 'OS.time', 'OS', 'riskscores', 'RS')],
            file.path(outdir, paste0(nm, '_Median_Risk_Groups.csv')), row.names = FALSE)
  fit <- survfit(Surv(OS.time, OS) ~ RS, data = d)
  p <- ggsurvplot(fit, data = d, pval = TRUE, risk.table = TRUE,
                  palette = c('#0048A1', '#AA1701'),
                  xlab = 'Overall survival (months)', ylab = 'Survival probability',
                  legend.title = nm, legend.labs = c('Low', 'High'), ggtheme = theme_bw())
  pdf(file.path(outdir, paste0(nm, '_KM_Median.pdf')), width = 7, height = 7)
  print(p)
  dev.off()
  model <- coxph(Surv(OS.time, OS) ~ riskscores, data = d)
  ci <- summary(model)$conf.int[1, ]
  summary_table <- rbind(summary_table,
    data.frame(Dataset = nm, N = nrow(d), Events = sum(d$OS),
               Median_cutoff = cutoff, Continuous_HR = ci['exp(coef)'],
               HR_lower = ci['lower .95'], HR_upper = ci['upper .95'],
               Cox_P = summary(model)$coefficients[1, 'Pr(>|z|)']))
}
write.csv(summary_table, file.path(outdir, 'USRS_Cohort_Cox_Summary.csv'), row.names = FALSE)

# 3. Time-dependent ROC in external cohorts (Fig. S4B) ------------
# Original evaluation uses timeROC weighting='marginal', iid=TRUE.
for (nm in c('ICGC', 'GSE14520', 'GSE116174')) {
  d <- cohorts[[nm]]
  eval_times <- c(12, 36, 60)
  # Restrict to times within observed follow-up, reporting skipped times.
  eval_times <- eval_times[eval_times < max(d$OS.time)]
  if (!length(eval_times)) next
  roc <- timeROC(T = d$OS.time, delta = d$OS, marker = d$riskscores,
                 cause = 1, weighting = 'marginal', times = eval_times,
                 ROC = TRUE, iid = TRUE)
  ci <- confint(roc, level = 0.95)$CI_AUC
  auc <- data.frame(Time_months = eval_times, AUC = roc$AUC,
                    CI_lower = ci[, 1] / 100, CI_upper = ci[, 2] / 100)
  write.csv(auc, file.path(outdir, paste0(nm, '_TimeROC_AUC_CI.csv')), row.names = FALSE)
  pdf(file.path(outdir, paste0(nm, '_TimeROC.pdf')), width = 6, height = 6)
  cols <- c('#D9534F', '#337AB7', '#5CB85C')[seq_along(eval_times)]
  plot(roc, time = eval_times[1], col = cols[1], title = FALSE, lwd = 2)
  if (length(eval_times) > 1) for (j in 2:length(eval_times))
    plot(roc, time = eval_times[j], add = TRUE, col = cols[j], lwd = 2)
  abline(0, 1, lty = 2, col = 'grey60')
  legend('bottomright', legend = paste0(eval_times / 12, '-year AUC: ',
         sprintf('%.3f', roc$AUC)), col = cols, lwd = 2, bty = 'n')
  dev.off()
}

# 4. Fixed TCGA-derived optimal cutoff (Fig. S4D) ------------------
# 0.6951 is the published/historical TCGA training cutoff; do not re-optimize.
fixed_cutoff <- 0.6951
for (nm in names(cohorts)) {
  d <- cohorts[[nm]]
  d$RS <- factor(ifelse(d$riskscores > fixed_cutoff, 'High', 'Low'),
                 levels = c('Low', 'High'))
  write.csv(d[, c('ID', 'OS.time', 'OS', 'riskscores', 'RS')],
            file.path(outdir, paste0(nm, '_Fixed_Cutoff_Groups.csv')), row.names = FALSE)
  if (length(unique(d$RS)) < 2) {
    warning('Only one risk group under fixed cutoff in ', nm)
    next
  }
  fit <- survfit(Surv(OS.time, OS) ~ RS, data = d)
  p <- ggsurvplot(fit, data = d, pval = TRUE, risk.table = TRUE,
                  palette = c('#0048A1', '#AA1701'),
                  xlab = 'Overall survival (months)', ylab = 'Survival probability',
                  legend.title = nm, legend.labs = c('Low', 'High'), ggtheme = theme_bw())
  pdf(file.path(outdir, paste0(nm, '_KM_Fixed_0.6951.pdf')), width = 7, height = 7)
  print(p)
  dev.off()
}

cat('Bulk_07 finished. Check time units.\n')
