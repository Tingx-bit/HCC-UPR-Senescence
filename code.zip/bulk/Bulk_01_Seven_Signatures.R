# Bulk_01 | Seven UPR/senescence signatures | Fig. S2A-G
# 314-patient cohort version adapted for public code sharing.
#
# Changes for repository portability:
#   - Replaced machine-specific absolute paths with paths relative to project_root.
#   - All code comments, folder names, and filenames use English.
#   - The GSVA method, patient matching, statistical analyses, and plotting
#     logic are unchanged from the supplied script.
#
# Cohort handling retained from the supplied 314-patient version:
#   - Read the clinical cohort from newdat/cli_TCGA.csv.
#   - Reduce tumour aliquots to 12-character patient IDs, retaining the first
#     occurrence per patient. The original author reported checking this
#     choice against newdat/f1_14image.RData.
#   - Join the 314-patient expression subset with clinical data by ID.
#
# Usage:
#   1. Set the R working directory to the repository root (for example,
#      by opening the project's .Rproj file or using setwd()).
#   2. Ensure input files are arranged as shown in the README.
#   3. Run this script. Outputs will be saved under results/Bulk_01/.

library(GSVA)
library(ggplot2)
library(dplyr)
library(tidyr)
library(survival)
library(pheatmap)

# All input and output paths are relative to the repository root.
project_root <- getwd()
input_path <- function(...) file.path(project_root, ...)
outdir <- input_path('results', 'Bulk_01')
dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

# Check that required inputs are present before running analyses.
pathway_names <- c('ATF6', 'DTSIS', 'IRE1', 'OIS', 'OSIS', 'PERK', 'SASP')
pathway_files <- file.path(project_root, 'data', 'pathway',
                           paste0(pathway_names, '.txt'))
expression_file <- input_path('data', 'tcga', 'TCGA_TPM.txt')
clinical_file <- input_path('newdat', 'cli_TCGA.csv')
mutation_file <- input_path('data', 'input.maf')
required_files <- c(expression_file, pathway_files, clinical_file, mutation_file)
missing_files <- required_files[!file.exists(required_files)]
if (length(missing_files) > 0L) {
  stop('Required input files not found:\n',
       paste(missing_files, collapse = '\n'),
       '\nSet the working directory to the repository root and check the data layout.')
}

# 1. Seven-signature GSVA scores (original method: GSVA, not ssGSEA)
exp_tcga_all <- read.delim(expression_file, row.names = 1,
                           check.names = FALSE)
exp_tcga_log_all <- log2(exp_tcga_all + 1)

gene_sets_list <- lapply(pathway_files, function(x) read.table(x, header = FALSE)[[1]])
names(gene_sets_list) <- pathway_names

gsvapar <- gsvaParam(as.matrix(exp_tcga_log_all), geneSets = gene_sets_list)
allsample_activity_scores <- gsva(gsvapar)

save(allsample_activity_scores, pathway_names,
     file = file.path(outdir, 'GSVA_seven_signatures.RData'))

# 2. Fig. S2A/B: distribution and tumor/normal comparison (all 424 samples)
group_info <- data.frame(sample_id = colnames(allsample_activity_scores))
group_info$tissue_code <- as.numeric(substr(group_info$sample_id, 14, 15))
group_info$Group <- ifelse(group_info$tissue_code < 10, 'Tumor', 'Normal')

score_long <- as.data.frame(t(allsample_activity_scores)) %>%
  tibble::rownames_to_column('sample_id') %>%
  left_join(group_info, by = 'sample_id') %>%
  pivot_longer(cols = all_of(pathway_names), names_to = 'Pathway', values_to = 'Score')

p1 <- ggplot(score_long, aes(Pathway, Score, fill = Pathway)) +
  geom_boxplot(outlier.shape = NA) + geom_jitter(width = 0.15, alpha = 0.2, size = 0.5) +
  theme_bw() + labs(x = NULL, y = 'GSVA score')
ggsave(file.path(outdir, 'FigS2A_score_distribution.pdf'), p1, width = 8, height = 5)

p2 <- ggplot(score_long, aes(Group, Score, fill = Group)) +
  geom_boxplot(outlier.shape = NA) +
  facet_wrap(~Pathway, scales = 'free_y') + theme_bw() +
  labs(x = NULL, y = 'GSVA score')
ggsave(file.path(outdir, 'FigS2B_tumor_normal.pdf'), p2, width = 10, height = 7)

# 3. Fig. S2C: Spearman correlation (all tumour samples)
tumor_samples <- group_info$sample_id[group_info$Group == 'Tumor']
tumor_scores <- allsample_activity_scores[, tumor_samples, drop = FALSE]
cor_matrix <- cor(t(tumor_scores), method = 'spearman')
write.csv(cor_matrix, file.path(outdir, 'FigS2C_spearman_matrix.csv'))
pdf(file.path(outdir, 'FigS2C_spearman.pdf'), width = 7, height = 6)
pheatmap(cor_matrix, display_numbers = TRUE)
dev.off()

# 4. 314-patient cohort (cohort handling retained from supplied script)
cli_TCGA <- read.csv(clinical_file, check.names = FALSE,
                     fileEncoding = 'UTF-8-BOM')
cli_TCGA$ID <- substr(cli_TCGA$ID, 1, 12)
cohort_ids <- unique(cli_TCGA$ID)
cat('clinical cohort:', length(cohort_ids), '\n')

score_df <- as.data.frame(t(allsample_activity_scores))
score_df$ID <- substr(rownames(score_df), 1, 12)
score_df <- score_df[!duplicated(score_df$ID), ]          # first aliquot per patient
tumor_data <- score_df %>% filter(ID %in% cohort_ids)
merged_data <- inner_join(tumor_data, cli_TCGA, by = 'ID')
cat('merged rows:', nrow(merged_data), ' unique IDs:', length(unique(merged_data$ID)), '\n')
stopifnot(nrow(merged_data) == length(cohort_ids))

# 5. Fig. S2D: TNM stage
stage_long <- merged_data %>%
  pivot_longer(cols = all_of(pathway_names), names_to = 'Pathway', values_to = 'Score')
p3 <- ggplot(stage_long, aes(Stage, Score, fill = Stage)) +
  geom_boxplot(outlier.shape = NA) + facet_wrap(~Pathway, scales = 'free_y') +
  theme_bw() + labs(x = 'TNM stage', y = 'GSVA score')
ggsave(file.path(outdir, 'FigS2D_TNM_stage.pdf'), p3, width = 10, height = 7)

stage_p <- stage_long %>% group_by(Pathway) %>%
  summarise(P = kruskal.test(Score ~ Stage)$p.value, .groups = 'drop')
write.csv(stage_p, file.path(outdir, 'FigS2D_Kruskal_Wallis.csv'), row.names = FALSE)

# 6. Fig. S2E: univariate Cox for OS and PFI
# The clinical input must expose the corrected PFI.months and PFI.status fields.
# Historical input files with legacy field names require a separately renamed copy.

cox_results <- data.frame()
for (endpoint in c('OS', 'PFI')) {
  for (pathway in pathway_names) {
    time <- merged_data[[paste0(endpoint, '.months')]]
    status <- merged_data[[paste0(endpoint, '.status')]]
    score <- merged_data[[pathway]]
    fit <- coxph(Surv(time, status) ~ score)
    s <- summary(fit)
    cox_results <- rbind(cox_results, data.frame(
      Endpoint = endpoint, Pathway = pathway,
      HR = s$conf.int[1, 'exp(coef)'],
      Lower95 = s$conf.int[1, 'lower .95'],
      Upper95 = s$conf.int[1, 'upper .95'],
      P = s$coefficients[1, 'Pr(>|z|)']))
  }
}
write.csv(cox_results, file.path(outdir, 'FigS2E_OS_PFI_Cox.csv'), row.names = FALSE)
p4 <- ggplot(cox_results, aes(HR, Pathway)) +
  geom_vline(xintercept = 1, linetype = 2) +
  geom_pointrange(aes(xmin = Lower95, xmax = Upper95)) +
  facet_wrap(~Endpoint) + theme_bw() +
  labs(x = 'HR (95% CI)', y = NULL)
ggsave(file.path(outdir, 'FigS2E_OS_PFI_Cox.pdf'), p4, width = 8, height = 5)

# 7. Fig. S2F/G: TP53 and CTNNB1 mutations
maf_raw <- read.delim(mutation_file, check.names = FALSE, skip = 7)
maf_raw$ID <- substr(maf_raw$Tumor_Sample_Barcode, 1, 12)
mutation_data <- merged_data %>% filter(ID %in% unique(maf_raw$ID))
tp53_ids <- unique(maf_raw$ID[maf_raw$Hugo_Symbol == 'TP53'])
ctnnb1_ids <- unique(maf_raw$ID[maf_raw$Hugo_Symbol == 'CTNNB1'])
mutation_data$TP53 <- ifelse(mutation_data$ID %in% tp53_ids, 'Mut', 'WT')
mutation_data$CTNNB1 <- ifelse(mutation_data$ID %in% ctnnb1_ids, 'Mut', 'WT')
mutation_data$Genotype <- paste(mutation_data$TP53, mutation_data$CTNNB1, sep = ' / ')

mutation_long <- mutation_data %>%
  pivot_longer(cols = all_of(pathway_names), names_to = 'Pathway', values_to = 'Score')
p5 <- ggplot(mutation_long, aes(Genotype, Score, fill = Genotype)) +
  geom_boxplot(outlier.shape = NA) + facet_wrap(~Pathway, scales = 'free_y') +
  theme_bw() + theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(x = 'TP53 / CTNNB1', y = 'GSVA score')
ggsave(file.path(outdir, 'FigS2G_mutation_boxplot.pdf'), p5, width = 11, height = 7)

annotation <- mutation_data[, c('TP53', 'CTNNB1')]
rownames(annotation) <- mutation_data$ID
mutation_matrix <- t(as.matrix(mutation_data[, pathway_names]))
colnames(mutation_matrix) <- mutation_data$ID
pdf(file.path(outdir, 'FigS2F_mutation_heatmap.pdf'), width = 10, height = 5)
pheatmap(mutation_matrix, annotation_col = annotation, show_colnames = FALSE,
         scale = 'row')
dev.off()
