# Bulk_03: NMF（Figure 1A–F）


library(dplyr)
library(tidyr)
library(ggplot2)
library(ComplexHeatmap)
library(circlize)
library(survival)
library(survminer)
library(ggpubr)
library(tibble)

load('./newdat/F2/F2.RData')
#cli_TCGA_k4、all_pathway_scores、cli_data_matched4
stopifnot(exists('cli_TCGA_k4'), exists('all_pathway_scores'),
          exists('cli_data_matched4'))

outdir <- './results/Bulk_03_new'

# Figure 1A:  -----------------------
# 
pathways7 <- c('ATF6','DTSIS','IRE1','OIS','OSIS','PERK','SASP')
clinical <- cli_data_matched4
clinical$ID <- as.character(clinical$ID)
clinical <- clinical[!duplicated(clinical$ID), ]
clinical <- clinical[order(clinical$Cluster, clinical$ID), ]
ids <- intersect(clinical$ID, colnames(all_pathway_scores))
clinical <- clinical[match(ids, clinical$ID), ]
score_mat <- as.matrix(all_pathway_scores[, ids, drop = FALSE])

ann <- data.frame(Cluster = factor(paste0('C', clinical$Cluster), levels = paste0('C', 1:4)))
rownames(ann) <- clinical$ID
pdf(file.path(outdir, 'Fig1A_Subtype_Heatmap.pdf'), width = 13, height = 10)
ht <- Heatmap(score_mat, name = 'Pathway score', top_annotation = HeatmapAnnotation(df = ann),
              column_split = ann$Cluster, show_column_names = FALSE,
              cluster_column_slices = FALSE, cluster_columns = FALSE,
              row_split = factor(ifelse(rownames(score_mat) %in% pathways7,
                                        'UPR / Senescence', 'Other pathways'),
                                 levels = c('UPR / Senescence','Other pathways')))
draw(ht)
dev.off()

# Figure 1B: --------------------------

pathway_data <- clinical %>%
  select(Cluster, 16:40) %>%
  mutate(Cluster = factor(Cluster, levels = 1:4, labels = paste0('C', 1:4))) %>%
  pivot_longer(-Cluster, names_to = 'Pathway', values_to = 'Score') %>%
  group_by(Cluster, Pathway) %>%
  summarise(Mean_Score = mean(Score, na.rm = TRUE), .groups = 'drop') %>%
  group_by(Pathway) %>%
  mutate(Relative_Activity = as.numeric(scale(Mean_Score))) %>%
  ungroup()

p_bubble <- ggplot(pathway_data, aes(Cluster, Pathway)) +
  geom_point(aes(size = abs(Mean_Score), color = Relative_Activity)) +
  scale_color_gradient2(low = '#4575b4', mid = 'white', high = '#d73027') +
  theme_bw() + labs(x = NULL, y = NULL, size = '|Mean score|', color = 'Relative activity')
ggsave(file.path(outdir, 'Fig1B_Pathway_Bubble.pdf'), p_bubble, width = 9, height = 9)
write.csv(pathway_data, file.path(outdir, 'Fig1B_Pathway_Data.csv'), row.names = FALSE)

# Figure 1C–D ---------------
immune <- clinical %>%
  select(Cluster, 43:70) %>%
  mutate(Cluster = factor(Cluster, levels = 1:4, labels = paste0('C', 1:4))) %>%
  pivot_longer(-Cluster, names_to = 'CellType', values_to = 'Score')

p_immune <- ggplot(immune, aes(CellType, Score, fill = Cluster)) +
  geom_boxplot(outlier.shape = NA, position = position_dodge(0.8)) +
  stat_compare_means(aes(group = Cluster), method = 'kruskal.test',
                     label = 'p.signif', hide.ns = TRUE) +
  theme_classic() + theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(x = NULL, y = 'Immune infiltration score')
ggsave(file.path(outdir, 'Fig1D_Immune.pdf'), p_immune, width = 14, height = 7)

stroma <- clinical %>%
  select(Cluster, 71:91) %>%
  mutate(Cluster = factor(Cluster, levels = 1:4, labels = paste0('C', 1:4))) %>%
  pivot_longer(-Cluster, names_to = 'CellType', values_to = 'Score')

p_stroma <- ggplot(stroma, aes(CellType, Score, fill = Cluster)) +
  geom_boxplot(outlier.shape = NA, position = position_dodge(0.8)) +
  stat_compare_means(aes(group = Cluster), method = 'kruskal.test',
                     label = 'p.signif', hide.ns = TRUE) +
  theme_classic() + theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(x = NULL, y = 'Stromal infiltration score')
ggsave(file.path(outdir, 'Fig1C_Stromal.pdf'), p_stroma, width = 14, height = 7)


immune_p <- immune %>% group_by(CellType) %>%
  summarise(P = kruskal.test(Score ~ Cluster)$p.value, .groups = 'drop')
stroma_p <- stroma %>% group_by(CellType) %>%
  summarise(P = kruskal.test(Score ~ Cluster)$p.value, .groups = 'drop')
write.csv(immune_p, file.path(outdir, 'Fig1D_Immune_Kruskal.csv'), row.names = FALSE)
write.csv(stroma_p, file.path(outdir, 'Fig1C_Stromal_Kruskal.csv'), row.names = FALSE)

# Figure 1E–F:  --------------------------
surv_data <- cli_TCGA_k4
surv_data$Cluster <- factor(surv_data$Cluster, levels = 1:4,
                            labels = paste0('C', 1:4))

fit_os <- survfit(Surv(OS.months, OS.status) ~ Cluster, data = surv_data)
p_os <- ggsurvplot(fit_os, data = surv_data, pval = TRUE, risk.table = TRUE,
                   xlab = 'Time (months)', ylab = 'Overall survival')
pdf(file.path(outdir, 'Fig1E_OS.pdf'), width = 8, height = 7)
print(p_os)
dev.off()

fit_pfi <- survfit(Surv(PFI.months, PFI.status) ~ Cluster, data = surv_data)
p_pfi <- ggsurvplot(fit_pfi, data = surv_data, pval = TRUE, risk.table = TRUE,
                    xlab = 'Time (months)', ylab = 'Progression-free interval')
pdf(file.path(outdir, 'Fig1F_PFI.pdf'), width = 8, height = 7)
print(p_pfi)
dev.off()

write.csv(data.frame(ID = clinical$ID, Cluster = clinical$Cluster),
          file.path(outdir, 'K4_Cluster_Labels.csv'), row.names = FALSE)
