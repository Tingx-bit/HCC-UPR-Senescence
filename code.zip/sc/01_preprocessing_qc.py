# -*- coding: utf-8 -*-
"""Preprocessing and quality control of HCC single-cell RNA-seq datasets.

Input: GSE149614 count matrix and metadata; GSE151530 10x matrix and metadata.
Output: merged counts, QC-filtered singlets, and Scrublet calls.
"""

from pathlib import Path

import numpy as np
import pandas as pd
import scanpy as sc
import scrublet as scr
from scipy import sparse


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data" / "raw"
OUTPUT_DIR = PROJECT_ROOT / "results" / "01_preprocessing_qc"

GSE149614_COUNTS = DATA_DIR / "GSE149614_HCC.scRNAseq.S71915.count.txt"
GSE149614_METADATA = DATA_DIR / "GSE149614_HCC.metadata.updated.csv"
GSE151530_10X = DATA_DIR / "gse151530sc"
GSE151530_METADATA = DATA_DIR / "GSE151530_Info.csv"

MIN_GENES_INITIAL = 200
MIN_CELLS_PER_GENE = 3
MIN_GENES = 1500
MAX_GENES = 8000
MAX_COUNTS = 120000
MAX_MITO_FRACTION = 0.15
DOUBLET_RATE = 0.10
DOUBLET_SCORE_THRESHOLD = 0.58


def load_datasets():
    """Load and merge the two datasets using shared genes."""
    data1 = sc.read_text(str(GSE149614_COUNTS)).T
    metadata1 = pd.read_csv(GSE149614_METADATA, index_col=0)
    data1.obs = metadata1.loc[data1.obs_names].copy()
    data1.var_names_make_unique()
    data1.obs["dataset"] = "dataset1"

    data2 = sc.read_10x_mtx(str(GSE151530_10X), var_names="gene_symbols", cache=True)
    metadata2 = pd.read_csv(GSE151530_METADATA, index_col=0)
    data2.obs = metadata2.set_index("Cell").loc[data2.obs_names].copy()
    data2.var_names_make_unique()
    data2.obs["dataset"] = "dataset2"

    data1 = data1[data1.obs["site"].isin(["Tumor", "Normal"])].copy()
    data2 = data2[data2.obs["Cancer_type"] == "HCC"].copy()

    shared_genes = data1.var_names.intersection(data2.var_names)
    data1 = data1[:, shared_genes].copy()
    data2 = data2[:, shared_genes].copy()

    data1.obs["batch"] = "data1"
    data2.obs["batch"] = "data2"
    adata = data1.concatenate(data2, join="inner", batch_key="batch")
    adata.obs["condition"] = adata.obs["site"].fillna(adata.obs["Cancer_type"])
    adata.obs["sample_id"] = adata.obs["sample"].fillna(adata.obs["Sample"])
    adata.obs["patient_id"] = adata.obs["patient"].fillna(adata.obs["Sample"])

    for column in ("batch", "condition", "sample_id", "patient_id"):
        adata.obs[column] = adata.obs[column].astype("category")

    adata.layers["counts"] = adata.X.copy()
    return adata


def filter_low_quality_cells(adata):
    """Filter cells using detected genes, total counts and mitochondrial fraction."""
    adata = adata.copy()
    sc.pp.filter_cells(adata, min_genes=MIN_GENES_INITIAL)
    sc.pp.filter_genes(adata, min_cells=MIN_CELLS_PER_GENE)

    mitochondrial_genes = adata.var_names.str.upper().str.startswith("MT-")
    mitochondrial_counts = np.asarray(adata[:, mitochondrial_genes].X.sum(axis=1)).ravel()
    total_counts = np.asarray(adata.X.sum(axis=1)).ravel()
    adata.obs["percent_mito"] = mitochondrial_counts / total_counts
    adata.obs["n_counts"] = total_counts
    if sparse.issparse(adata.X):
        adata.obs["n_genes"] = np.asarray((adata.X > 0).sum(axis=1)).ravel()
    else:
        adata.obs["n_genes"] = np.count_nonzero(adata.X, axis=1)

    keep = (
        (adata.obs["n_genes"] > MIN_GENES)
        & (adata.obs["n_genes"] < MAX_GENES)
        & (adata.obs["n_counts"] < MAX_COUNTS)
        & (adata.obs["percent_mito"] < MAX_MITO_FRACTION)
    )
    return adata[keep, :].copy()


def remove_doublets(adata):
    """Detect doublets with Scrublet on the merged QC-filtered matrix."""
    # Match the original pipeline's dense-matrix input to Scrublet.
    counts_matrix = adata.X.copy()
    if not isinstance(counts_matrix, np.ndarray):
        counts_matrix = counts_matrix.toarray()

    scrublet = scr.Scrublet(counts_matrix, expected_doublet_rate=DOUBLET_RATE)
    scores, _ = scrublet.scrub_doublets()
    calls = scrublet.call_doublets(threshold=DOUBLET_SCORE_THRESHOLD)
    adata.obs["doublet_score"] = scores
    adata.obs["predicted_doublet"] = calls

    calls_table = pd.DataFrame(
        {
            "cell_barcodes": adata.obs_names,
            "doublet_score": scores,
            "predicted_doublet": calls,
        }
    )
    singlets = adata[~adata.obs["predicted_doublet"].to_numpy(), :].copy()
    return singlets, calls_table



def export_qc_figures(merged, qc_filtered, singlets):
    """Fig. S7A-C: pre-/post-QC distributions and counts-versus-genes."""
    import matplotlib.pyplot as plt
    fig_dir = OUTPUT_DIR / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)
    pre = merged.copy()
    sc.pp.filter_cells(pre, min_genes=MIN_GENES_INITIAL)
    sc.pp.filter_genes(pre, min_cells=MIN_CELLS_PER_GENE)
    for obj in (pre,):
        total = np.asarray(obj.X.sum(axis=1)).ravel()
        mito = np.asarray(obj[:, obj.var_names.str.upper().str.startswith("MT-")].X.sum(axis=1)).ravel()
        obj.obs["n_counts"] = total
        obj.obs["n_genes"] = np.asarray((obj.X > 0).sum(axis=1)).ravel()
        obj.obs["percent_mito"] = np.divide(mito, total, out=np.zeros_like(mito, dtype=float), where=total>0)
    for obj, name in ((pre, "FigS7A_pre_filter"), (qc_filtered, "FigS7B_post_thresholds")):
        fig, axes = plt.subplots(1, 3, figsize=(13, 3.5))
        for ax, col, label in zip(axes, ("n_genes", "n_counts", "percent_mito"), ("Detected genes", "Total counts", "Mitochondrial fraction")):
            ax.hist(obj.obs[col].dropna(), bins=60)
            ax.set_xlabel(label)
            ax.set_ylabel("Cells")
        fig.tight_layout();fig.savefig(fig_dir/f"{name}.pdf", bbox_inches="tight");plt.close(fig)
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    ax.scatter(qc_filtered.obs["n_counts"], qc_filtered.obs["n_genes"], s=2, alpha=.3)
    ax.set(xlabel="n_counts", ylabel="n_genes")
    fig.tight_layout();fig.savefig(fig_dir/"FigS7C_counts_vs_genes.pdf", bbox_inches="tight");plt.close(fig)
    # Historical Scrublet histogram also available from raw source; do not re-run Scrublet here.

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    merged = load_datasets()
    qc_filtered = filter_low_quality_cells(merged)
    singlets, doublet_calls = remove_doublets(qc_filtered)
    export_qc_figures(merged, qc_filtered, singlets)

    merged.write_h5ad(OUTPUT_DIR / "adata_merged.h5ad")
    singlets.write_h5ad(OUTPUT_DIR / "adata_qc_filtered_no_doublets.h5ad")
    doublet_calls.to_csv(OUTPUT_DIR / "scrublet_doublet_calls.csv", index=False)

    print(f"Merged cells: {merged.n_obs:,}")
    print(f"Cells after QC: {qc_filtered.n_obs:,}")
    print(f"Cells after doublet removal: {singlets.n_obs:,}")
    print(f"Saved results to: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
