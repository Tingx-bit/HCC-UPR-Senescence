# -*- coding: utf-8 -*-
"""Stage06 | Malignant-cell subclustering.

Validated software environment:
    Python 3.10.14; Scanpy 1.10.2; scvi-tools 1.3.3;
    umap-learn 0.5.9.post2; pynndescent 0.5.13;
    leidenalg 0.10.2; igraph 0.11.9.

Input: annotated AnnData containing obs['cell_type_coarse'] and obsm['X_scVI'].
Example (from project root):
    python scripts/06_malignant_subclustering_clean.py --input results/03_cell_type_annotation/adata_annoed.h5ad

The script starts from an existing scVI embedding; it does not retrain scVI.
"""

import argparse
import json
import sys
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import scanpy as sc


SUBTYPE_MAP = {"0": "C2", "1": "C3", "2": "C4", "3": "C1"}
SUBTYPE_ORDER = ["C1", "C2", "C3", "C4"]
# Manuscript names MalC1-MalC4 refer to these stored C1-C4 labels.


def installed_version(package):
    try:
        return version(package)
    except PackageNotFoundError:
        return None


def main():
    parser = argparse.ArgumentParser(description="Stage06 malignant-cell subclustering")
    parser.add_argument("--input", type=Path, default=Path("adata_annoed.h5ad"),
                        help="Annotated AnnData with X_scVI (default: ./adata_annoed.h5ad)")
    parser.add_argument("--output", type=Path, default=Path("results/stage06"),
                        help="Output directory (default: ./results/stage06)")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    output_files = [
        args.output / "adata_Mal.h5ad",
        args.output / "adata_annoed_with_malignant_subclusters.h5ad",
        args.output / "malignant_subclusters.csv",
        args.output / "subcluster_counts.csv",
        args.output / "malignant_subclusters_umap.png",
        args.output / "malignant_subclusters_umap.pdf",
        args.output / "stage06_metadata.json",
    ]
    existing_outputs = [str(path) for path in output_files if path.exists()]
    if existing_outputs:
        raise FileExistsError("Refusing to overwrite existing outputs: " +
                              ", ".join(existing_outputs))

    adata = sc.read_h5ad(args.input)
    if "cell_type_coarse" not in adata.obs:
        raise KeyError("Input lacks cell_type_coarse")
    if not adata.obs_names.is_unique:
        raise ValueError("Input cell IDs are not unique")
    malignant = adata[adata.obs["cell_type_coarse"].astype(str) == "Malignant cell"].copy()
    if malignant.n_obs == 0 or "X_scVI" not in malignant.obsm:
        raise ValueError("No malignant cells or X_scVI embedding found in the input")
    if not malignant.obs_names.is_unique:
        raise ValueError("Malignant-cell IDs are not unique")

    # Graph and clustering parameters recovered from the original Stage06 workflow.
    sc.pp.neighbors(malignant, use_rep="X_scVI", n_neighbors=15,
                    n_pcs=malignant.obsm["X_scVI"].shape[1],
                    random_state=2025)
    for resolution in (0.2, 0.4, 1.0):
        sc.tl.leiden(malignant, resolution=resolution,
                     key_added=f"leiden_{resolution}",
                     random_state=0, n_iterations=-1,
                     flavor="leidenalg", directed=True)
    sc.tl.umap(malignant, random_state=2025, min_dist=0.4)

    labels = malignant.obs["leiden_0.2"].astype(str).map(SUBTYPE_MAP)
    if labels.isna().any() or not labels.isin(SUBTYPE_ORDER).all():
        raise ValueError("Leiden 0.2 produced clusters not covered by SUBTYPE_MAP")
    if len(labels) != malignant.n_obs or not labels.index.isin(adata.obs_names).all():
        raise ValueError("Malignant-cell label coverage or cell IDs do not match the input")
    if "cell_type_fine" in adata.obs:
        previous = adata.obs.loc[labels.index, "cell_type_fine"].astype("string")
        known = previous.notna() & previous.ne("")
        if known.any() and not previous[known].eq(labels[known]).all():
            raise ValueError("New labels disagree with existing malignant-cell labels")
    malignant.obs["cell_type_fine"] = pd.Categorical(labels, categories=SUBTYPE_ORDER)

    # Transfer by unique cell ID, preserving existing nonmalignant fine annotations.
    full_labels = (adata.obs["cell_type_fine"].astype("string").copy()
                   if "cell_type_fine" in adata.obs else
                   adata.obs["cell_type_coarse"].astype("string").copy())
    full_labels.loc[labels.index] = labels.astype("string")
    adata.obs["cell_type_fine"] = full_labels.astype("category")
    transferred = adata.obs.loc[labels.index, "cell_type_fine"].astype("string")
    if (len(transferred) != malignant.n_obs or transferred.isna().any() or
            not transferred.eq(labels.astype("string")).all()):
        raise ValueError("Malignant-cell label transfer is incomplete")

    malignant.write_h5ad(args.output / "adata_Mal.h5ad")
    adata.write_h5ad(args.output / "adata_annoed_with_malignant_subclusters.h5ad")
    malignant.obs[["leiden_0.2", "leiden_0.4", "leiden_1.0", "cell_type_fine"]].to_csv(
        args.output / "malignant_subclusters.csv", encoding="utf-8-sig")
    malignant.obs["cell_type_fine"].value_counts().reindex(SUBTYPE_ORDER).to_csv(
        args.output / "subcluster_counts.csv", header=["n_cells"])

    sc.pl.umap(malignant, color="cell_type_fine", legend_loc="on data",
               frameon=False, show=False)
    plt.savefig(args.output / "malignant_subclusters_umap.png", dpi=300, bbox_inches="tight")
    plt.savefig(args.output / "malignant_subclusters_umap.pdf", bbox_inches="tight")
    plt.close("all")

    metadata = {
        "python": sys.version.split()[0],
        "software_versions": {
            p: installed_version(p) for p in
            ("scanpy", "scvi-tools", "umap-learn", "pynndescent", "leidenalg", "igraph")
        },
        "parameters": {
            "representation": "X_scVI", "n_neighbors": 15,
            "neighbors_random_state": 2025,
            "leiden_resolutions": [0.2, 0.4, 1.0],
            "leiden_random_state": 0, "leiden_n_iterations": -1,
            "umap_random_state": 2025, "umap_min_dist": 0.4,
            "subtype_map": SUBTYPE_MAP,
        },
    }
    (args.output / "stage06_metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    print("Stage06 completed:", malignant.n_obs, "malignant cells")
    print(malignant.obs["cell_type_fine"].value_counts().reindex(SUBTYPE_ORDER))
    print("Results:", args.output)


if __name__ == "__main__":
    main()
