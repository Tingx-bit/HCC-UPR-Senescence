# -*- coding: utf-8 -*-
"""Differential expression and GO/KEGG enrichment of malignant cell subclusters."""

from pathlib import Path

import gseapy as gp
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
from matplotlib.lines import Line2D


INPUT_FILE = Path('adata_Malcyto.h5ad')
RESULT_DIR = Path('enrichment_results')
PLOT_DIR = Path('enrichment_plots')
CLUSTERS = ('C1', 'C2', 'C3', 'C4')
GENE_SETS = ('GO_Biological_Process_2023', 'KEGG_2021_Human')
COLORS = {'C1': '#E41A1C', 'C2': '#377EB8', 'C3': '#4DAF4A', 'C4': '#984EA3'}


def plot_cluster(enrichment, cluster, n_genes):
    top = enrichment.sort_values('Adjusted P-value').head(10)
    fig, ax = plt.subplots(figsize=(12, 8))
    y = np.arange(len(top))
    ax.barh(y, -np.log10(top['Adjusted P-value'].to_numpy(dtype=float)))
    ax.set_yticks(y, top['Term'])
    ax.set_xlabel('-log10(Adjusted P-value)')
    ax.set_title(f'Cluster {cluster} - Top 10 Enriched Terms\n(n={n_genes} genes)')
    ax.grid(axis='x', alpha=0.3)
    fig.tight_layout()
    fig.savefig(PLOT_DIR / f'cluster_{cluster}_enrichment.png', dpi=150)
    plt.close(fig)


def plot_combined(combined, counts):
    fig, ax = plt.subplots(figsize=(14, 12))
    positions, labels, points = [], [], []
    y = 0.0

    for cluster in CLUSTERS:
        subset = combined.loc[combined['Cluster'] == cluster]
        if subset.empty:
            continue
        positions.append(y)
        labels.append(f'{cluster} ({counts[cluster]} cells)')
        ax.axhspan(y - 0.25, y + 0.25, facecolor=COLORS[cluster], alpha=0.25)
        y += 0.8
        for _, row in subset.nlargest(5, 'Combined Score').iterrows():
            term = str(row['Term']).split(' (GO:')[0]
            if len(term) > 60:
                term = term[:57] + '...'
            score = float(row['Combined Score'])
            logp = -np.log10(max(float(row['Adjusted P-value']), np.finfo(float).tiny))
            positions.append(y)
            labels.append('  ' + term)
            points.append((y, score, logp, cluster))
            y += 0.9
        y += 0.3

    max_score = max(point[1] for point in points)
    for pos, score, logp, cluster in points:
        color = COLORS[cluster]
        ax.plot([0, score], [pos, pos], color=color, linewidth=1.8, alpha=0.7)
        ax.scatter(score, pos, s=40 + logp * 12, color=color,
                   edgecolor='white', linewidth=1.2, alpha=0.85, zorder=5)
        ax.text(score + max_score * 0.015, pos, f'{score:.1f}',
                va='center', fontsize=11, color='dimgray')

    ax.set_yticks(positions, labels=labels, fontsize=13)
    ax.invert_yaxis()
    ax.set_xlabel('Combined Score', fontsize=15, fontweight='bold')
    ax.set_xlim(0, max_score * 1.12)
    ax.grid(axis='x', alpha=0.2, linestyle='--')
    ax.legend(handles=[
        Line2D([0], [0], marker='o', color='w', markerfacecolor='gray',
               markeredgecolor='black', markersize=12,
               label='Point size: -log10(Adj P-value)'),
        Line2D([0], [0], color='gray', linewidth=2,
               label='Line length: Combined Score')
    ], loc='upper right', fontsize=12)
    fig.tight_layout(rect=[0, 0, 0.9, 1])
    fig.savefig('enriched_terms_compact_large_font.png', dpi=300, bbox_inches='tight')
    fig.savefig('enriched_terms_compact_large_font.pdf', bbox_inches='tight')
    plt.close(fig)


def main():
    RESULT_DIR.mkdir(exist_ok=True)
    PLOT_DIR.mkdir(exist_ok=True)

    adata = sc.read_h5ad(INPUT_FILE)
    sc.tl.rank_genes_groups(adata, groupby='cell_type_fine', method='wilcoxon')
    counts = adata.obs['cell_type_fine'].value_counts().to_dict()
    ranks = adata.uns['rank_genes_groups']
    all_enrichments = []

    for cluster in CLUSTERS:
        deg = pd.DataFrame({
            field: ranks[field][cluster]
            for field in ('names', 'scores', 'pvals', 'pvals_adj', 'logfoldchanges')
        })
        significant = deg.loc[
            (deg['pvals_adj'] < 0.05) & (deg['logfoldchanges'] > 0.5)
        ]
        if len(significant) < 5:
            continue

        genes = significant.sort_values('scores', ascending=False)['names'].head(100).tolist()
        enrichment = gp.enrichr(
            gene_list=genes,
            gene_sets=list(GENE_SETS),
            organism='human',
            outdir=None,
            cutoff=0.05,
        ).results

        significant.to_csv(
            RESULT_DIR / f'cluster_{cluster}_differential_genes.csv', index=False
        )
        enrichment.to_csv(RESULT_DIR / f'cluster_{cluster}_enrichment.csv', index=False)
        plot_cluster(enrichment, cluster, len(genes))
        all_enrichments.append(enrichment.assign(Cluster=cluster))

    combined = pd.concat(all_enrichments, ignore_index=True)
    combined.to_csv(RESULT_DIR / 'combined_enrichment_results.csv', index=False)
    top_pathways = pd.concat([
        combined.loc[combined['Cluster'] == cluster]
        .sort_values('Adjusted P-value').head(5)[['Term', 'Adjusted P-value', 'Cluster']]
        for cluster in CLUSTERS
    ], ignore_index=True)
    top_pathways.to_csv(RESULT_DIR / 'top_pathways_by_cluster.csv', index=False)
    plot_combined(combined, counts)


if __name__ == '__main__':
    main()
