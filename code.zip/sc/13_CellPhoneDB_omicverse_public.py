# -*- coding: utf-8 -*-


from pathlib import Path
import matplotlib
import matplotlib.pyplot as plt
import scanpy as sc
import omicverse as ov
import pandas as pd

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans']

# 1. Inputs and analysis (unchanged core parameters)
root = Path('.')
out = root / 'cpdb_results_omicverse'
figdir = out / 'figures'
out.mkdir(exist_ok=True)
figdir.mkdir(exist_ok=True)

adata = sc.read_h5ad(root / 'adata_annoed.h5ad')
assert 'cell_type_fine3' in adata.obs, 'Missing cell_type_fine3'
print('OmicVerse version:', ov.__version__)
print('Cell types:', adata.obs['cell_type_fine3'].value_counts())

# Set to False to load previously saved outputs instead of re-running inference.
run_inference = True
if run_inference:
    cpdb_results, adata_cpdb = ov.single.run_cellphonedb_v5(
        adata=adata,
        cpdb_file_path=str(root / 'cellphonedb.zip'),
        celltype_key='cell_type_fine3',
        iterations=1000,
        threshold=0.1,
        pvalue=0.05,
        threads=5,
        min_cell_fraction=0.005,
        output_dir=str(out),
        cleanup_temp=True,
    )
    ov.utils.save(cpdb_results, str(out / 'gex_cpdb_test.pkl'))
    adata_cpdb.write(out / 'gex_cpdb_ad.h5ad')
else:
    cpdb_results = ov.utils.load(str(out / 'gex_cpdb_test.pkl'))
    adata_cpdb = sc.read_h5ad(out / 'gex_cpdb_ad.h5ad')

# The original uses the annotated cell-type colors.
if 'cell_type_fine3_colors' in adata.uns:
    labels = adata.obs['cell_type_fine3'].astype('category').cat.categories
    color_dict = dict(zip(labels, adata.uns['cell_type_fine3_colors']))
    viz = ov.pl.CellChatViz(adata_cpdb, palette=color_dict)
else:
    viz = ov.pl.CellChatViz(adata_cpdb)

# 2. Fig. S10A: global signaling role (sender versus receiver)
fig, ax = viz.netAnalysis_signalingRole_scatter(
    signaling=None, x_measure='outdegree', y_measure='indegree',
    title='', figsize=(4, 4)
)
fig.savefig(figdir / 'FigS10A_signaling_role_scatter.pdf', bbox_inches='tight')
plt.close(fig)

# 3. Related signaling role analyses in the original script.
# These are HEATMAPS, not the bar plots described as Fig. S10B/C.
# Keep them as supplementary outputs; do not mislabel as the published panels.
for pattern in ('outgoing', 'incoming'):
    result = viz.netAnalysis_signalingRole_heatmap(
        pattern=pattern, signaling=None, row_scale=False,
        figsize=(6, 6), cmap='Greens', show_totals=True,
        title=f'{pattern.title()} Signaling Role', save=None
    )
    heatmap = result[0]
    heatmap.render()
    plt.gcf().savefig(figdir / f'signaling_role_{pattern}_heatmap.pdf',
                      bbox_inches='tight')
    plt.close('all')

# 4. Original pathway-level computation and APO pathway selection.
# Two threshold configurations occur in the original exploration.
# The initial configuration below is preserved; the alternative was
# strength_threshold=0.5, min_significant_pairs=1.
pathway_comm = viz.compute_pathway_communication(
    method='mean', min_lr_pairs=2, min_expression=0.1
)
sig_pathways, pathway_summary = viz.get_significant_pathways_v2(
    pathway_comm, strength_threshold=0.2,
    pvalue_threshold=0.05, min_significant_pairs=4
)

apo = 'Signaling by Apolipoprotein'

# 5. Fig. S10D: apolipoprotein pathway network.
# Original plot includes all cell types. The statement that MalC1-C3 are
# core senders must be supported by the plotted results, not imposed here.
fig, ax = viz.netVisual_aggregate(
    signaling=[apo], layout='circle', figsize=(5, 5),
    vertex_size_max=10
)
fig.savefig(figdir / 'FigS10D_apolipoprotein_network.pdf',
            bbox_inches='tight')
plt.close(fig)

# 6. Fig. S10E: contributions of ligand-receptor pairs.
contribution_df, fig, axes = viz.netAnalysis_contribution(apo)
contribution_df.to_csv(out / 'Apolipoprotein_LR_contributions.csv',
                       index=False, encoding='utf-8-sig')
fig.savefig(figdir / 'FigS10E_apolipoprotein_contribution.pdf',
            bbox_inches='tight')
plt.close(fig)

# 7. Fig. S10F: apolipoprotein bubble plot, C3 as sender.
# The original contains several trial thresholds (p=1, 0.1, 0.05, 0.5).
# This is the explicitly labeled p=0.05, mean=0.01 version.
# Verify that this matches the submitted figure before declaring exact reproduction.
viz.netVisual_bubble_marsilea(
    sources_use=['C3'],
    signaling=[apo],
    pvalue_threshold=0.05,
    mean_threshold=0.01,
    top_interactions=500,
    cmap='RdBu_r',
    show_pvalue=False,
    show_mean=False,
    show_count=True,
    add_dendrogram=False,
    font_size=10,
    group_pathways=False,
    figsize=(14, 4),
    transpose=True,
    title=apo,
    remove_isolate=False,
)
plt.savefig(figdir / 'FigS10F_apolipoprotein_bubble.pdf',
            bbox_inches='tight')
plt.close('all')

# Original also inspected individual LR chord plots, including:
# APOE_TREM2_receptor, APOA2_TREM2_receptor, APOA1_ABCA1.
# Retain as separate, directly traceable exploratory outputs.
for lr in ('APOE_TREM2_receptor', 'APOA2_TREM2_receptor', 'APOA1_ABCA1'):
    fig, ax = viz.netVisual_chord_LR(
        ligand_receptor_pairs=lr, count_min=1, figsize=(5, 5),
        sources=['C3'], rotate_names=True
    )
    fig.savefig(figdir / f'LR_chord_{lr}.pdf', bbox_inches='tight')
    plt.close(fig)

# 8. Fig. S10G: APOE and TREM2 expression violin.
# Original script does NOT contain a complete APOE/TREM2 violin figure.
# Do not substitute a newly created plot as if it were the historical one.
# Recover the original normalization/layer choice and figure settings first.

# 9. Fig. S10H: TCGA-LIHC TREM2 overall survival (n=370).
# The supplied script contains no clinical data or corresponding KM code.
# This panel requires the original TCGA cohort, survival variables, sample
# filtering and expression cutpoint; it cannot be reproduced from CPDB data.

print('Stage13 core analysis and available plots exported to:', figdir.resolve())
print('TO VERIFY: S10B/C bar plots, S10F exact original thresholds,')
print('           S10G expression violin and S10H TCGA n=370 survival.')
