# -*- coding: utf-8 -*-
"""Myeloid subclustering, based on the exploratory myeloid annotation script.

The source used 'leiden_0.2' for its six-cluster annotation, but only created
0.3/0.7/1.0 in the visible script. For faithful reconstruction, this script
requires an existing 'leiden_0.2' field in the archived myeloid object. It
will not invent a 0.2 clustering or relabel a different resolution.

Candidate labels were inspired by the published pan-cancer myeloid atlas:
'A pan-cancer single-cell transcriptional atlas of tumor infiltrating myeloid cells'.
Verify marker support before treating the labels as validated cell identities.
"""
from pathlib import Path
import pandas as pd
import scanpy as sc

ROOT = Path(__file__).resolve().parent.parent
INPUT = ROOT / 'results' / '03_cell_type_annotation' / 'adata_annoed.h5ad'
ARCHIVED_SUBSET = ROOT / 'data' / 'processed' / 'adata_Myeloid.h5ad'
OUTPUT = ROOT / 'results' / '04_myeloid_subannotation'
GROUP = 'leiden_0.2'
LABELS = {
    '0': 'Macro_C1QC', '1': 'Mono_FCN1', '2': 'Prolif_Myeloid',
    '3': 'Macro_CD5L', '4': 'cDC1_CLEC9A', '5': 'pDC_LILRA4',
}


MYELOID_MARKERS = {
    "Macro_C1QC": ["C1QA", "C1QB", "C1QC"],
    "Mono_FCN1": ["FCN1", "S100A8", "S100A9"],
    "Prolif_Myeloid": ["MKI67", "TOP2A"],
    "Macro_CD5L": ["CD5L", "APOE"],
    "cDC1_CLEC9A": ["CLEC9A", "XCR1"],
    "pDC_LILRA4": ["LILRA4", "CLEC4C", "IL3RA"],
}

def export_myeloid_figures(adata):
    """Fig. S7H-I: archived six-subcluster UMAP and marker DotPlot."""
    import matplotlib.pyplot as plt
    fig_dir = OUTPUT / "figures";fig_dir.mkdir(parents=True, exist_ok=True)
    if "X_umap" not in adata.obsm:
        if "X_scVI" not in adata.obsm: raise KeyError("No UMAP or scVI embedding in myeloid object")
        sc.pp.neighbors(adata, use_rep="X_scVI", n_neighbors=15, random_state=2025)
        sc.tl.umap(adata, random_state=2025, min_dist=.4)
    fig = sc.pl.umap(adata, color="cell_type_fine", legend_loc="right margin", show=False, return_fig=True)
    fig.savefig(fig_dir/"FigS7H_myeloid_subclusters.pdf", bbox_inches="tight");plt.close(fig)
    plot_data = adata.copy()
    if "counts" in plot_data.layers:
        plot_data.X = plot_data.layers["counts"].copy()
        sc.pp.normalize_total(plot_data, target_sum=1e4);sc.pp.log1p(plot_data)
    markers = {k: [g for g in v if g in plot_data.var_names] for k,v in MYELOID_MARKERS.items()}
    markers = {k:v for k,v in markers.items() if v}
    if markers:
        dp = sc.pl.dotplot(plot_data, markers, groupby="cell_type_fine", standard_scale="var", show=False, return_fig=True)
        dp.savefig(fig_dir/"FigS7I_myeloid_markers.pdf");plt.close("all")

def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    if ARCHIVED_SUBSET.is_file():
        adata = sc.read_h5ad(ARCHIVED_SUBSET)
    else:
        adata = sc.read_h5ad(INPUT)
        adata = adata[adata.obs['cell_type_coarse'] == 'Myeloid cell'].copy()
    if GROUP not in adata.obs:
        raise RuntimeError(
            "Historical Leiden 0.2 clustering is absent. Source created "
            "0.3/0.7/1.0 but annotated 0.2; verify the historical object "
            "before applying these candidate labels."
        )
    clusters = adata.obs[GROUP].astype(str)
    unknown = set(clusters) - set(LABELS)
    if unknown:
        raise ValueError(f'Unmapped clusters: {sorted(unknown)}')
    adata.obs['cell_type_fine'] = clusters.map(LABELS).astype('category')
    adata.obs['cell_type_fine'].value_counts().to_csv(OUTPUT / 'myeloid_subtype_counts.csv')
    export_myeloid_figures(adata)
    adata.write_h5ad(OUTPUT / 'adata_Myeloid_annotated.h5ad')

if __name__ == '__main__':
    main()
