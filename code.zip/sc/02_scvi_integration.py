# -*- coding: utf-8 -*-
"""Tumor-sample selection, scVI integration, and initial clustering.

Input: results/01_preprocessing_qc/adata_qc_filtered_no_doublets.h5ad
Output: results/02_scvi_integration/adata_scvi_integrated.h5ad

This script retains the final processing steps and parameters from the
original analysis pipeline. It does not change the upstream QC or doublet calls.
"""

from pathlib import Path

import pandas as pd
import scanpy as sc
import scvi


PROJECT_ROOT = Path(__file__).resolve().parent.parent
INPUT_FILE = (
    PROJECT_ROOT / "results" / "01_preprocessing_qc"
    / "adata_qc_filtered_no_doublets.h5ad"
)
OUTPUT_DIR = PROJECT_ROOT / "results" / "02_scvi_integration"

MIN_CELLS_PER_SAMPLE = 100
BATCH_KEY = "sample_id"
N_LATENT = 30
N_LAYERS = 2
N_NEIGHBORS = 15
LEIDEN_RESOLUTIONS = (0.8, 1.2)
RANDOM_STATE = 2025
UMAP_MIN_DIST = 0.4


def select_tumor_samples(adata):
    """Exclude normal samples and samples containing fewer than 100 cells."""
    sample_ids = adata.obs[BATCH_KEY].astype(str)
    tumor_mask = ~sample_ids.str.endswith("N")
    tumor = adata[tumor_mask.to_numpy(), :].copy()

    sample_counts = tumor.obs[BATCH_KEY].astype(str).value_counts()
    excluded = sample_counts[sample_counts < MIN_CELLS_PER_SAMPLE]
    retained = sample_counts[sample_counts >= MIN_CELLS_PER_SAMPLE].index
    tumor = tumor[tumor.obs[BATCH_KEY].astype(str).isin(retained).to_numpy(), :].copy()

    tumor.obs[BATCH_KEY] = tumor.obs[BATCH_KEY].astype("category")
    for column in ("batch", "condition"):
        if column in tumor.obs:
            tumor.obs[column] = tumor.obs[column].astype("category")

    return tumor, excluded, sample_counts


def integrate_and_cluster(adata):
    """Train scVI on raw counts and cluster in the learned latent space."""
    if "counts" not in adata.layers:
        # The upstream QC module preserves unnormalized counts in X.
        adata.layers["counts"] = adata.X.copy()

    scvi.model.SCVI.setup_anndata(adata, layer="counts", batch_key=BATCH_KEY)
    model = scvi.model.SCVI(
        adata,
        n_layers=N_LAYERS,
        n_latent=N_LATENT,
        gene_likelihood="nb",
    )
    model.train()
    adata.obsm["X_scVI"] = model.get_latent_representation()

    sc.pp.neighbors(adata, use_rep="X_scVI", n_neighbors=N_NEIGHBORS)
    for resolution in LEIDEN_RESOLUTIONS:
        sc.tl.leiden(
            adata,
            resolution=resolution,
            random_state=RANDOM_STATE,
            key_added=f"leiden_scvi_{resolution}",
        )
    sc.tl.umap(adata, random_state=RANDOM_STATE, min_dist=UMAP_MIN_DIST)
    adata.obsm["X_umap_scVI"] = adata.obsm["X_umap"].copy()

    return adata, model



def export_integration_comparison(adata):
    """Fig. S7D: original PCA-neighbor UMAP versus scVI-neighbor UMAP."""
    import matplotlib.pyplot as plt
    fig_dir = OUTPUT_DIR / "figures";fig_dir.mkdir(parents=True, exist_ok=True)
    # Preserve the scVI coordinates before computing the pre-correction UMAP.
    adata.obsm["X_umap_scVI"] = adata.obsm["X_umap"].copy()
    sc.tl.pca(adata, svd_solver="arpack")
    sc.pp.neighbors(adata, use_rep="X_pca", n_neighbors=15, n_pcs=30, key_added="pre_correction")
    sc.tl.umap(adata, neighbors_key="pre_correction")
    adata.obsm["X_umap_pre"] = adata.obsm["X_umap"].copy()
    adata.obsm["X_umap"] = adata.obsm["X_umap_scVI"].copy()
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, basis, title in zip(axes, ("X_umap_pre", "X_umap_scVI"), ("Pre-correction (PCA)", "Post-correction (scVI)")):
        sc.pl.embedding(adata, basis=basis, color="sample_id", ax=ax, show=False, frameon=False, title=title)
    fig.tight_layout();fig.savefig(fig_dir/"FigS7D_PCA_vs_scVI.pdf", bbox_inches="tight");plt.close(fig)

def main():
    if not INPUT_FILE.is_file():
        raise FileNotFoundError(f"QC input not found: {INPUT_FILE}")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    adata = sc.read_h5ad(INPUT_FILE)
    adata, excluded, sample_counts = select_tumor_samples(adata)
    excluded.rename("cell_count").to_csv(
        OUTPUT_DIR / "excluded_small_samples.tsv", sep="\t", header=True
    )
    sample_counts.rename("cell_count").to_csv(
        OUTPUT_DIR / "tumor_sample_counts_before_size_filter.csv", header=True
    )

    adata, model = integrate_and_cluster(adata)
    export_integration_comparison(adata)
    adata.write_h5ad(OUTPUT_DIR / "adata_scvi_integrated.h5ad")
    print(f"Integrated data: {adata.n_obs:,} cells x {adata.n_vars:,} genes")
    print(f"Samples: {adata.obs[BATCH_KEY].nunique()}")


if __name__ == "__main__":
    main()
