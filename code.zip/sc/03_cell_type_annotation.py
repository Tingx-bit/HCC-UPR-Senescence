# -*- coding: utf-8 -*-
"""Cell-type annotation of HCC single-cell RNA-seq data.

A custom CellTypist classifier is trained using a published HCC reference
expression matrix and its cell-type annotations. Predicted labels are reviewed
against canonical markers before final cluster-level assignments.

Reference atlas:
    Sun Y, Wu L, Zhong Y, et al. Single-cell landscape of the ecosystem
    in early-relapse hepatocellular carcinoma. Cell. 2021;184:404-421.e16.
    https://doi.org/10.1016/j.cell.2020.11.041

Annotation software:
    CellTypist v1.7.1 (cite the CellTypist methods publication in the paper).

Reference inputs:
    HCC_log_tpm_expression_matrix.txt.gz
    HCC_cell_metadata.txt

Input: scVI-integrated AnnData.
Outputs: trained CellTypist model, cluster marker tables, annotated AnnData.
"""

from pathlib import Path

import celltypist
import pandas as pd
import scanpy as sc
from celltypist import models

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data" / "raw"
INPUT_FILE = PROJECT_ROOT / "results" / "02_scvi_integration" / "adata_scvi_integrated.h5ad"
OUTPUT_DIR = PROJECT_ROOT / "results" / "03_cell_type_annotation"
REFERENCE_EXPRESSION = DATA_DIR / "HCC_log_tpm_expression_matrix.txt.gz"
REFERENCE_METADATA = DATA_DIR / "HCC_cell_metadata.txt"
MODEL_FILE = OUTPUT_DIR / "HCC_Cell_CellTypist_coarse.pkl"
CLUSTER_KEY = "leiden_scvi_0.8"

# Historical final labels: assigned after reviewing CellTypist predictions,
# Leiden-cluster differential markers, and canonical marker expression.
# This dictionary records the original manual decisions; it is not an
# automated inference from CellTypist predictions.
CLUSTER_TO_CELL_TYPE = {
    "0": "Malignant cell", "2": "Malignant cell", "4": "Malignant cell",
    "6": "Malignant cell", "7": "Malignant cell", "10": "Malignant cell",
    "19": "Malignant cell",
    "12": "Plasma cell", "16": "B cell", "13": "NK cell",
    "3": "T cell", "11": "T cell",
    "5": "Endothelial cell", "14": "Endothelial cell",
    "8": "HSC",
    "1": "Myeloid cell", "15": "Myeloid cell", "9": "Myeloid cell",
    "17": "Myeloid cell",
    # CellTypist-predicted pDCs (101 cells) belonged to cluster 18 and
    # were retained within the broad myeloid category.
    "18": "Myeloid cell",
}

MARKER_GENES = {
    "Malignant": ["ALB", "APOA1", "APOC3", "TTR", "KRT8", "KRT18", "KRT19", "EPCAM", "TACSTD2", "GPC3"],
    "T cell": ["CD3D", "CD3E", "TRAC", "CD4", "CD8A", "CD8B", "IL7R"],
    "NK cell": ["NKG7", "GNLY", "PRF1", "KLRD1"],
    "B cell": ["MS4A1", "CD79A", "CD79B", "CD74"],
    "Plasma cell": ["MZB1", "XBP1", "TNFRSF17", "JCHAIN", "SDC1"],
    "Myeloid": ["LST1", "S100A8", "C1QA", "C1QB", "C1QC", "APOE"],
    "Endothelial": ["PECAM1", "VWF", "KDR", "EMCN"],
    "HSC": ["COL1A1", "COL1A2", "DCN", "LUM", "PDGFRB"],
    "pDC": ["LILRA4", "CLEC4C", "GZMB", "IRF7", "IL3RA"],
}

REFERENCE_LABEL_MAPPING = {
    "Tcell": "T cell", "NK": "NK cell", "Bcell": "B lineage",
    "Plasma": "B lineage", "Mye": "Myeloid", "Mey": "Myeloid",
    "pDC": "pDC", "Endo": "Endothelial cell", "HSC": "HSC",
    "Tumor": "Tumor cell", "Epi": "Epithelial cell",
}


def load_reference():
    """Build the reference AnnData using published labels."""
    expr = pd.read_csv(REFERENCE_EXPRESSION, sep="\t", index_col=0)
    meta = pd.read_csv(REFERENCE_METADATA, sep="\t")
    meta = meta.loc[meta["name"] != "type"].copy()
    meta = meta.set_index("sample_name", drop=False)

    reference = sc.AnnData(expr.T)
    reference.var_names = expr.index.astype(str)
    if not reference.obs_names.isin(meta.index).all():
        missing = reference.obs_names[~reference.obs_names.isin(meta.index)]
        raise ValueError(f"Reference metadata missing {len(missing)} cells")
    reference.obs = meta.loc[reference.obs_names].copy()
    raw_labels = reference.obs["cell_type"].astype(str)
    simple_labels = (raw_labels.str.replace(r"^C\d+_", "", regex=True)
                     .str.replace(r"\.$", "", regex=True))
    reference.obs["cell_type_clean"] = simple_labels.replace(REFERENCE_LABEL_MAPPING)
    # Match the preprocessing applied to the training reference in the source script.
    sc.pp.normalize_total(reference, target_sum=1e4)
    sc.pp.log1p(reference)
    return reference


def train_reference_model(reference):
    """Train the custom CellTypist classifier used for coarse annotation."""
    model = celltypist.train(
        reference, labels="cell_type_clean", n_jobs=8, feature_selection=True
    )
    model.write(str(MODEL_FILE))
    return model


def annotate_with_celltypist(adata):
    """Apply CellTypist to normalized raw counts without modifying scVI input."""
    if "counts" not in adata.layers:
        raise KeyError("Expected unnormalized counts in adata.layers['counts']")
    ct_input = adata.copy()
    ct_input.X = ct_input.layers["counts"].copy()
    sc.pp.normalize_total(ct_input, target_sum=1e4)
    sc.pp.log1p(ct_input)
    predictions = celltypist.annotate(
        ct_input, model=str(MODEL_FILE), majority_voting=True
    ).to_adata()
    if not predictions.obs_names.equals(adata.obs_names):
        raise ValueError("CellTypist predictions are not aligned to input cells")
    adata.obs["ct_pred"] = predictions.obs["predicted_labels"].to_numpy()
    adata.obs["ct_majority"] = predictions.obs["majority_voting"].to_numpy()
    return adata


def export_cluster_markers(adata):
    """Export Wilcoxon marker lists used to support cluster annotation."""
    marker_input = adata.copy()
    marker_input.X = marker_input.layers["counts"].copy()
    sc.pp.normalize_total(marker_input, target_sum=1e4)
    sc.pp.log1p(marker_input)
    sc.tl.rank_genes_groups(
        marker_input, groupby=CLUSTER_KEY, method="wilcoxon",
        use_raw=False, pts=True
    )
    marker_dir = OUTPUT_DIR / "cluster_markers"
    marker_dir.mkdir(parents=True, exist_ok=True)
    for cluster in marker_input.obs[CLUSTER_KEY].cat.categories:
        table = sc.get.rank_genes_groups_df(marker_input, group=cluster)
        table.to_csv(marker_dir / f"cluster_{cluster}_markers.csv", index=False)


def export_annotation_checks(adata):
    """Export reference predictions and marker plots for manual review."""
    import matplotlib.pyplot as plt

    adata.obs[["ct_pred", "ct_majority", CLUSTER_KEY]].to_csv(
        OUTPUT_DIR / "celltypist_predictions.csv"
    )
    pd.crosstab(adata.obs["ct_majority"], adata.obs[CLUSTER_KEY]).to_csv(
        OUTPUT_DIR / "celltypist_by_leiden.csv"
    )
    plot_data = adata.copy()
    plot_data.X = plot_data.layers["counts"].copy()
    sc.pp.normalize_total(plot_data, target_sum=1e4)
    sc.pp.log1p(plot_data)
    markers = {k: [g for g in genes if g in plot_data.var_names]
               for k, genes in MARKER_GENES.items()}
    markers = {k: genes for k, genes in markers.items() if genes}
    if markers:
        dp = sc.pl.dotplot(plot_data, markers, groupby=CLUSTER_KEY,
                           standard_scale="var", dendrogram=False, show=False,
                           return_fig=True)
        dp.savefig(OUTPUT_DIR / "canonical_markers_dotplot.pdf")
        plt.close("all")
    for gene in MARKER_GENES["pDC"]:
        if gene in plot_data.var_names and "X_umap" in plot_data.obsm:
            sc.pl.umap(plot_data, color=gene, show=False)
            plt.savefig(OUTPUT_DIR / f"pDC_marker_{gene}_umap.pdf", bbox_inches="tight")
            plt.close("all")


def apply_final_labels(adata):
    """Apply the historical manual cluster labels after annotation review."""
    observed = set(adata.obs[CLUSTER_KEY].astype(str).unique())
    missing = observed - set(CLUSTER_TO_CELL_TYPE)
    if missing:
        raise ValueError(f"Unmapped Leiden clusters: {sorted(missing)}")
    adata.obs["cell_type_coarse"] = (
        adata.obs[CLUSTER_KEY].astype(str).map(CLUSTER_TO_CELL_TYPE).astype("category")
    )
    return adata



USRS_RISK_GENES = ["CDCA8", "KIF2C", "PLK1"]
USRS_PROTECTIVE_GENES = ["HPD", "HPR", "CCL16", "ADH4", "ADH1B", "PCK1", "SPP2", "GLYAT", "CYP3A4"]
HEATMAP_GENES = [
    "MS4A1", "CD79A", "CD79B", "CD74", "BANK1",
    "VWF", "PECAM1", "KDR", "EMCN", "ENG",
    "ACTA2", "COL1A1", "COL1A2", "COL3A1", "COL6A1",
    "GPC3", "EPCAM", "ALB", "APOA1", "APOC3",
    "C1QA", "APOE", "LST1", "S100A8", "S100A9",
    "NKG7", "GNLY", "PRF1", "KLRD1", "KLRB1",
    "MZB1", "XBP1", "TNFRSF17", "JCHAIN", "SDC1",
    "CD3D", "TRAC", "CD3E", "CD4", "CD8A",
]

def export_figure4_abc(adata):
    """Fig. 4A-C: annotated UMAP, historical downsampled marker heatmap, USRS genes."""
    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib.colors import LinearSegmentedColormap
    fig_dir = OUTPUT_DIR / "figures"; fig_dir.mkdir(parents=True, exist_ok=True)
    fig = sc.pl.umap(adata, color="cell_type_coarse", frameon=False, show=False, return_fig=True)
    fig.savefig(fig_dir / "Fig4A_cell_types_umap.pdf", bbox_inches="tight");plt.close(fig)
    plot_data = adata.copy()
    plot_data.X = plot_data.layers["counts"].copy()
    sc.pp.normalize_total(plot_data, target_sum=1e4);sc.pp.log1p(plot_data)
    # Original exploratory plot sampled up to 100 cells per annotated category.
    rng = np.random.default_rng(2025)  # Explicit reproducibility seed; not recorded in source.
    sampled = []
    for group in plot_data.obs["cell_type_coarse"].cat.categories:
        ids = plot_data.obs_names[plot_data.obs["cell_type_coarse"] == group].to_numpy()
        sampled.extend(rng.choice(ids, min(100, len(ids)), replace=False).tolist())
    available = [g for g in HEATMAP_GENES if g in plot_data.var_names]
    if available:
        cmap = LinearSegmentedColormap.from_list("white_red", ["#FFFFFF", "#FFE6E6", "#FFCCCC", "#FF9999", "#FF6666", "#FF3333", "#FF0000"])
        sc.pl.heatmap(plot_data[sampled].copy(), var_names=available, groupby="cell_type_coarse", standard_scale="var", swap_axes=True, show_gene_labels=True, cmap=cmap, dendrogram=False, figsize=(12,10), vmin=0, vmax=1, show=False)
        plt.savefig(fig_dir / "Fig4B_celltype_marker_heatmap.pdf", bbox_inches="tight");plt.close("all")
    for gene in USRS_RISK_GENES + USRS_PROTECTIVE_GENES:
        if gene not in plot_data.var_names:
            print(f"Warning: USRS gene missing from matrix: {gene}");continue
        fig, ax = plt.subplots(figsize=(8,6))
        sc.pl.umap(plot_data, color=gene, ax=ax, show=False, frameon=True, size=30, color_map="Spectral_r", vmax="p99", title=f"{gene} Expression")
        fig.savefig(fig_dir / f"Fig4C_umap_{gene}.pdf", bbox_inches="tight");plt.close(fig)

def main():
    for input_path in (INPUT_FILE, REFERENCE_EXPRESSION, REFERENCE_METADATA):
        if not input_path.is_file():
            raise FileNotFoundError(input_path)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    adata = sc.read_h5ad(INPUT_FILE)
    reference = load_reference()
    train_reference_model(reference)
    adata = annotate_with_celltypist(adata)
    export_cluster_markers(adata)
    export_annotation_checks(adata)
    # Apply the historical marker-guided assignments only after exporting
    # CellTypist predictions and marker evidence for review.
    adata = apply_final_labels(adata)
    pd.crosstab(adata.obs["ct_majority"], adata.obs["cell_type_coarse"]).to_csv(
        OUTPUT_DIR / "celltypist_vs_final_annotation.csv"
    )
    adata.obs["cell_type_coarse"].value_counts().rename("n_cells").to_csv(
        OUTPUT_DIR / "cell_type_counts.csv", header=True
    )
    export_figure4_abc(adata)
    adata.write_h5ad(OUTPUT_DIR / "adata_annoed.h5ad")
    print(f"Annotated {adata.n_obs:,} cells; output: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
