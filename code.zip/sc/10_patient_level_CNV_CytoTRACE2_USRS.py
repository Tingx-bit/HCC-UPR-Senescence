# -*- coding: utf-8 -*-
"""Patient-level comparison of USRS, CytoTRACE2 and CNV across malignant subclusters."""

from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import seaborn as sns
from scipy.stats import wilcoxon
from statsmodels.stats.multitest import multipletests

ANNOTATED_FILE = Path('results/stage06/adata_annoed_with_malignant_subclusters.h5ad')
MALIGNANT_FILE = Path('adata_Malcyto.h5ad')
OUTPUT_DIR = Path('patient_level_results')
CLUSTERS = ('C1', 'C2', 'C3', 'C4')
COLORS = {'C1': '#A6CEE3', 'C2': '#B2DF8A', 'C3': '#FB9A99', 'C4': '#CAB2D6'}
MIN_CELLS = 10
METRICS = {'USRS': 'risk_score_cell_combined',
           'CytoTRACE2': 'CytoTRACE2_Score',
           'cnv_score': 'cnv_score'}
PATIENT_MERGES = {'H58a': 'H58', 'H58c': 'H58',
                  'H68a': 'H68', 'H68b': 'H68',
                  'H73a': 'H73', 'H73b': 'H73'}


def prepare_cells(annotated, malignant):
    required = {'cell_type_coarse', 'cell_type_fine', 'dataset', 'patient_id'}
    missing = required.difference(annotated.obs.columns)
    if missing:
        raise KeyError(f'Annotated object lacks fields: {sorted(missing)}')
    if not annotated.obs_names.is_unique or not malignant.obs_names.is_unique:
        raise ValueError('Cell IDs must be unique in both input objects')
    obs = annotated.obs.loc[
        annotated.obs['cell_type_coarse'] == 'Malignant cell'
    ].copy()
    if (obs.empty or len(obs.index.difference(malignant.obs_names)) or
            len(malignant.obs_names.difference(obs.index))):
        raise ValueError('Malignant-cell IDs do not match between input objects')
    labels = obs['cell_type_fine'].astype('string')
    if labels.isna().any() or not labels.isin(CLUSTERS).all():
        raise ValueError('Malignant-cell subtype labels are missing or incomplete')
    if 'cell_type_fine' in malignant.obs:
        saved_labels = malignant.obs['cell_type_fine'].astype('string').reindex(obs.index)
        if saved_labels.isna().any() or not saved_labels.eq(labels).all():
            raise ValueError('Malignant-cell subtype labels disagree by cell ID')
    cells = pd.DataFrame(index=obs.index)
    cells['dataset'] = obs['dataset'].astype(str)
    cells['patient_id'] = obs['patient_id'].astype(str)
    cells['subcluster'] = obs['cell_type_fine'].astype(str)
    patient = cells['patient_id'].copy()
    is_dataset2 = cells['dataset'].eq('dataset2')
    patient.loc[is_dataset2] = patient.loc[is_dataset2].replace(PATIENT_MERGES)
    cells['patient_unique'] = cells['dataset'] + '_' + patient

    for metric, source in METRICS.items():
        if source in obs.columns:
            cells[metric] = pd.to_numeric(obs[source], errors='coerce')
        else:
            cells[metric] = pd.to_numeric(
                malignant.obs[source].reindex(cells.index), errors='coerce'
            )
    return cells.loc[cells['subcluster'].isin(CLUSTERS)]


def aggregate(cells, metric):
    summary = (
        cells[['patient_unique', 'subcluster', metric]]
        .dropna()
        .groupby(['patient_unique', 'subcluster'], as_index=False)
        .agg(n_cells=(metric, 'size'), **{metric + '_mean': (metric, 'mean')})
    )
    return summary.loc[summary['n_cells'] >= MIN_CELLS].copy()


def compare(pb, metric):
    value = metric + '_mean'
    wide = pb.pivot(index='patient_unique', columns='subcluster', values=value)
    rows = []
    for other in ('C1', 'C2', 'C4'):
        paired = wide.dropna(subset=[other, 'C3'])
        diff = paired['C3'] - paired[other]
        p = wilcoxon(diff).pvalue if len(diff) and np.any(diff != 0) else np.nan
        rows.append({'metric': metric, 'comparison': f'C3 vs {other}',
                     'n_patients': len(diff), 'C3_higher': int((diff > 0).sum()),
                     'C3_lower': int((diff < 0).sum()), 'p_raw': p})
    table = pd.DataFrame(rows)
    valid = table['p_raw'].notna()
    table['p_holm'] = np.nan
    if valid.any():
        table.loc[valid, 'p_holm'] = multipletests(
            table.loc[valid, 'p_raw'], method='holm'
        )[1]
    return table, wide


def plot_metric(pb, wide, stats, metric, ylabel, filename, comparisons):
    value = metric + '_mean'
    fig, ax = plt.subplots(figsize=(7.2, 6.2))
    sns.boxplot(data=pb, x='subcluster', y=value, order=CLUSTERS,
                hue='subcluster', palette=COLORS, dodge=False,
                width=0.55, showfliers=False, linewidth=1.1, ax=ax)
    legend = ax.get_legend()
    if legend is not None:
        legend.remove()
    sns.stripplot(data=pb, x='subcluster', y=value, order=CLUSTERS,
                  color='black', size=3.5, jitter=0, alpha=0.7, ax=ax)
    ymin, ymax = pb[value].min(), pb[value].max()
    span = max(ymax - ymin, 1e-6)
    for i, other in enumerate(comparisons):
        paired = wide.dropna(subset=[other, 'C3'])
        x1, x2 = CLUSTERS.index(other), CLUSTERS.index('C3')
        for _, row in paired.iterrows():
            ax.plot([x1, x2], [row[other], row['C3']],
                    color='gray', alpha=0.3, linewidth=0.6, zorder=0)
        result = stats.loc[stats['comparison'] == f'C3 vs {other}'].iloc[0]
        y = ymax + (0.13 + i * 0.16) * span
        ax.plot([x1, x1, x2, x2],
                [y - 0.02 * span, y, y, y - 0.02 * span],
                color='black', linewidth=1)
        ax.text((x1 + x2) / 2, y + 0.02 * span,
                f"Holm P = {result['p_holm']:.3g} (n={int(result['n_patients'])})",
                ha='center', fontsize=8.5)
    ax.set_ylim(ymin - 0.08 * span, ymax + (0.35 + 0.16 * len(comparisons)) * span)
    ax.set_xlabel('Malignant subcluster')
    ax.set_ylabel(ylabel)
    ax.spines[['top', 'right']].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / filename, bbox_inches='tight')
    plt.close(fig)


def main():
    OUTPUT_DIR.mkdir(exist_ok=True)
    cells = prepare_cells(sc.read_h5ad(ANNOTATED_FILE), sc.read_h5ad(MALIGNANT_FILE))
    cells.to_csv(OUTPUT_DIR / 'malignant_cell_scores.csv', index_label='cell_id')
    tables = []
    settings = {
        'USRS': ('Patient-level USRS', 'Fig4E_USRS_Holm.pdf', ('C2',)),
        'CytoTRACE2': ('Patient-level CytoTRACE2 score',
                       'Fig4F_CytoTRACE2_Holm.pdf', ('C2', 'C4')),
        'cnv_score': ('Patient-level CNV score',
                      'FigCNV_Holm.pdf', ('C2', 'C4')),
    }
    for metric, (ylabel, filename, comparisons) in settings.items():
        pb = aggregate(cells, metric)
        pb.to_csv(OUTPUT_DIR / f'patient_by_subcluster_{metric}.csv', index=False)
        stats, wide = compare(pb, metric)
        tables.append(stats)
        plot_metric(pb, wide, stats, metric, ylabel, filename, comparisons)
    pd.concat(tables, ignore_index=True).to_csv(
        OUTPUT_DIR / 'patient_level_paired_wilcoxon_holm.csv', index=False
    )


if __name__ == '__main__':
    main()
