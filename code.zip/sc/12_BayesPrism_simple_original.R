# Stage 12 | BayesPrism deconvolution and C3 abundance
# Simplified from the supplied original R analysis. No computed results are included.
# Run from the project directory. All file names below are relative to that directory.
# Required: BayesPrism, data.table, survival, survminer.
# Input: bayesprism_sc_counts.csv (cells x genes), bayesprism_sc_meta.csv
# Bulk files: TCGA_loged.txt, GSE14520_loged.txt, GSE116174_loged.txt, ICGC_loged.txt
# Clinical files: cli_use_314.txt, cli_gse14520.csv, cli_gse116174.csv, cli_ICGC.csv


library(BayesPrism)
library(data.table)
library(survival)
library(survminer)

dir.create('Stage12_results', showWarnings = FALSE)

# 1. Single-cell reference (same filtering settings as original)
sc.dat <- fread('bayesprism_sc_counts.csv', data.table = FALSE, check.names = FALSE)
rownames(sc.dat) <- sc.dat[, 1]
sc.dat <- as.matrix(sc.dat[, -1, drop = FALSE])
storage.mode(sc.dat) <- 'numeric'
cell_meta <- read.csv('bayesprism_sc_meta.csv', row.names = 1, check.names = FALSE)
stopifnot(!anyDuplicated(rownames(sc.dat)), !anyDuplicated(rownames(cell_meta)))
stopifnot(all(rownames(sc.dat) %in% rownames(cell_meta)))
cell_meta <- cell_meta[rownames(sc.dat), , drop = FALSE]
stopifnot(all(c('cell_type_coarse', 'cell_type_fine3') %in% colnames(cell_meta)))
stopifnot('C3' %in% cell_meta$cell_type_fine3)
stopifnot(!anyNA(sc.dat), all(sc.dat >= 0))

sc.dat.filtered <- cleanup.genes(
  input = sc.dat, input.type = 'count.matrix', species = 'hs',
  gene.group = c('Rb', 'Mrp', 'other_Rb', 'chrM', 'MALAT1', 'chrX', 'chrY'),
  exp.cells = 5
)
sc.dat.pc <- select.gene.type(sc.dat.filtered, gene.type = 'protein_coding')

# 2. TCGA: deconvolution
exp_tcga <- read.delim('TCGA_loged.txt', row.names = 1, check.names = FALSE)
bulk.dat <- 2^(t(as.matrix(exp_tcga))) - 1
bulk.dat[bulk.dat < 0] <- 0
common_genes <- intersect(colnames(sc.dat.pc), colnames(bulk.dat))
stopifnot(length(common_genes) > 0)
prism.obj <- new.prism(
  reference = sc.dat.pc[, common_genes, drop = FALSE],
  mixture = bulk.dat[, common_genes, drop = FALSE],
  input.type = 'count.matrix',
  cell.type.labels = as.character(cell_meta$cell_type_coarse),
  cell.state.labels = as.character(cell_meta$cell_type_fine3),
  key = NULL
)
bp_tcga <- run.prism(prism = prism.obj, n.cores = 8)
saveRDS(bp_tcga, 'Stage12_results/BayesPrism_TCGA_result.rds')
theta_tcga <- get.fraction(bp = bp_tcga, which.theta = 'first', state.or.type = 'state')
stopifnot(all(c('C1', 'C2', 'C3', 'C4') %in% colnames(theta_tcga)))
write.csv(data.frame(Sample = rownames(theta_tcga), C3_Score = theta_tcga[, 'C3']),
          'Stage12_results/C3_abundance_TCGA_first.csv', row.names = FALSE)

# 3. GSE14520: deconvolution
exp_14520 <- read.delim('GSE14520_loged.txt', row.names = 1, check.names = FALSE)
bulk.dat <- 2^(t(as.matrix(exp_14520))) - 1
bulk.dat[bulk.dat < 0] <- 0
common_genes <- intersect(colnames(sc.dat.pc), colnames(bulk.dat))
stopifnot(length(common_genes) > 0)
prism.obj <- new.prism(
  reference = sc.dat.pc[, common_genes, drop = FALSE],
  mixture = bulk.dat[, common_genes, drop = FALSE],
  input.type = 'count.matrix',
  cell.type.labels = as.character(cell_meta$cell_type_coarse),
  cell.state.labels = as.character(cell_meta$cell_type_fine3), key = NULL
)
bp_14520 <- run.prism(prism = prism.obj, n.cores = 8)
saveRDS(bp_14520, 'Stage12_results/BayesPrism_GSE14520_result.rds')
theta_14520 <- get.fraction(bp = bp_14520, which.theta = 'first', state.or.type = 'state')
stopifnot(all(c('C1', 'C2', 'C3', 'C4') %in% colnames(theta_14520)))
write.csv(data.frame(Sample = rownames(theta_14520), C3_Score = theta_14520[, 'C3']),
          'Stage12_results/C3_abundance_GSE14520.csv', row.names = FALSE)

# 4. GSE116174: deconvolution
exp_116174 <- read.delim('GSE116174_loged.txt', row.names = 1, check.names = FALSE)
bulk.dat <- 2^(t(as.matrix(exp_116174))) - 1
bulk.dat[bulk.dat < 0] <- 0
common_genes <- intersect(colnames(sc.dat.pc), colnames(bulk.dat))
stopifnot(length(common_genes) > 0)
prism.obj <- new.prism(
  reference = sc.dat.pc[, common_genes, drop = FALSE],
  mixture = bulk.dat[, common_genes, drop = FALSE],
  input.type = 'count.matrix',
  cell.type.labels = as.character(cell_meta$cell_type_coarse),
  cell.state.labels = as.character(cell_meta$cell_type_fine3), key = NULL
)
bp_116174 <- run.prism(prism = prism.obj, n.cores = 8)
saveRDS(bp_116174, 'Stage12_results/BayesPrism_GSE116174_result.rds')
theta_116174 <- get.fraction(bp = bp_116174, which.theta = 'first', state.or.type = 'state')
stopifnot(all(c('C1', 'C2', 'C3', 'C4') %in% colnames(theta_116174)))
write.csv(data.frame(Sample = rownames(theta_116174), C3_Score = theta_116174[, 'C3']),
          'Stage12_results/C3_abundance_GSE116174.csv', row.names = FALSE)

# 5. ICGC: deconvolution
exp_icgc <- read.delim('ICGC_loged.txt', row.names = 1, check.names = FALSE)
bulk.dat <- 2^(t(as.matrix(exp_icgc))) - 1
bulk.dat[bulk.dat < 0] <- 0
common_genes <- intersect(colnames(sc.dat.pc), colnames(bulk.dat))
stopifnot(length(common_genes) > 0)
prism.obj <- new.prism(
  reference = sc.dat.pc[, common_genes, drop = FALSE],
  mixture = bulk.dat[, common_genes, drop = FALSE],
  input.type = 'count.matrix',
  cell.type.labels = as.character(cell_meta$cell_type_coarse),
  cell.state.labels = as.character(cell_meta$cell_type_fine3), key = NULL
)
bp_icgc <- run.prism(prism = prism.obj, n.cores = 8)
saveRDS(bp_icgc, 'Stage12_results/BayesPrism_ICGC_result.rds')
theta_icgc <- get.fraction(bp = bp_icgc, which.theta = 'first', state.or.type = 'state')
stopifnot(all(c('C1', 'C2', 'C3', 'C4') %in% colnames(theta_icgc)))
write.csv(data.frame(Sample = rownames(theta_icgc), C3_Score = theta_icgc[, 'C3']),
          'Stage12_results/C3_abundance_ICGC.csv', row.names = FALSE)

# 6. TCGA: C3 abundance, OS and PFI (original cohort-median grouping)
cli_tcga <- read.delim('cli_use_314.txt', check.names = FALSE)
tcga <- data.frame(Sample = rownames(theta_tcga), C3_Absolute = theta_tcga[, 'C3'])
tcga$ID <- substr(gsub('\\.', '-', tcga$Sample), 1, 12)
cli_tcga$ID <- substr(gsub('\\.', '-', cli_tcga$ID), 1, 12)
tcga <- merge(tcga, cli_tcga, by = 'ID')
tcga$C3_Group <- ifelse(tcga$C3_Absolute > median(tcga$C3_Absolute, na.rm = TRUE), 'High', 'Low')
write.csv(tcga, 'Stage12_results/TCGA_C3_clinical_merged.csv', row.names = FALSE)
fit <- survfit(Surv(OS.months, OS.status) ~ C3_Group, data = tcga)
p <- ggsurvplot(fit, data = tcga, pval = TRUE, risk.table = TRUE,
                palette = c('#E41A1C', '#377EB8'), title = 'TCGA: C3 abundance vs OS')
pdf('Stage12_results/TCGA_C3_KM_OS.pdf', width = 6.5, height = 6.5); print(p); dev.off()
fit <- survfit(Surv(PFI.months, PFI.status) ~ C3_Group, data = tcga)
p <- ggsurvplot(fit, data = tcga, pval = TRUE, risk.table = TRUE,
                palette = c('#E41A1C', '#377EB8'), title = 'TCGA: C3 abundance vs PFI')
pdf('Stage12_results/TCGA_C3_KM_PFI.pdf', width = 6.5, height = 6.5); print(p); dev.off()

# 7. GSE14520: C3 abundance, OS and RFS
cli_14520 <- read.csv('cli_gse14520.csv', check.names = FALSE)
x <- data.frame(Sample = rownames(theta_14520), C3_Absolute = theta_14520[, 'C3'])
x$ID <- trimws(x$Sample)
cli_14520$ID <- trimws(as.character(cli_14520[, 2]))  # Original used clinical column 2
x <- merge(x, cli_14520, by = 'ID')
x$C3_Group <- ifelse(x$C3_Absolute > median(x$C3_Absolute, na.rm = TRUE), 'High', 'Low')
write.csv(x, 'Stage12_results/GSE14520_C3_clinical_merged.csv', row.names = FALSE)
fit <- survfit(Surv(as.numeric(OS.months), as.numeric(OS.status)) ~ C3_Group, data = x)
p <- ggsurvplot(fit, data = x, pval = TRUE, risk.table = TRUE,
                palette = c('#E41A1C', '#377EB8'), title = 'GSE14520: C3 abundance vs OS')
pdf('Stage12_results/GSE14520_C3_KM_OS.pdf', width = 6, height = 6); print(p); dev.off()
fit <- survfit(Surv(as.numeric(RFS.months), as.numeric(RFS.status)) ~ C3_Group, data = x)
p <- ggsurvplot(fit, data = x, pval = TRUE, risk.table = TRUE,
                palette = c('#E41A1C', '#377EB8'), title = 'GSE14520: C3 abundance vs RFS')
pdf('Stage12_results/GSE14520_C3_KM_RFS.pdf', width = 6, height = 6); print(p); dev.off()

# 8. GSE116174: C3 abundance and OS
cli_116174 <- read.csv('cli_gse116174.csv', check.names = FALSE)
x <- data.frame(Sample = rownames(theta_116174), C3_Absolute = theta_116174[, 'C3'])
x$ID <- trimws(x$Sample)
cli_116174$ID <- trimws(as.character(cli_116174$sample))
x <- merge(x, cli_116174, by = 'ID')
x$C3_Group <- ifelse(x$C3_Absolute > median(x$C3_Absolute, na.rm = TRUE), 'High', 'Low')
write.csv(x, 'Stage12_results/GSE116174_C3_clinical_merged.csv', row.names = FALSE)
fit <- survfit(Surv(as.numeric(Follow_up.time.month.), as.numeric(Event_death)) ~ C3_Group, data = x)
p <- ggsurvplot(fit, data = x, pval = TRUE, risk.table = TRUE,
                palette = c('#E41A1C', '#377EB8'), title = 'GSE116174: C3 abundance vs OS')
pdf('Stage12_results/GSE116174_C3_KM_OS.pdf', width = 6, height = 6); print(p); dev.off()

# 9. ICGC: C3 abundance and OS
cli_icgc <- read.csv('cli_ICGC.csv', check.names = FALSE)
x <- data.frame(Sample = rownames(theta_icgc), C3_Absolute = theta_icgc[, 'C3'])
x$ID <- trimws(x$Sample)
cli_icgc$ID <- trimws(as.character(cli_icgc[, 2]))  # Original used clinical column 2
x <- merge(x, cli_icgc, by = 'ID')
x$C3_Group <- ifelse(x$C3_Absolute > median(x$C3_Absolute, na.rm = TRUE), 'High', 'Low')
write.csv(x, 'Stage12_results/ICGC_C3_clinical_merged.csv', row.names = FALSE)
fit <- survfit(Surv(as.numeric(OS.months), as.numeric(OS.status)) ~ C3_Group, data = x)
p <- ggsurvplot(fit, data = x, pval = TRUE, risk.table = TRUE,
                palette = c('#E41A1C', '#377EB8'), title = 'ICGC: C3 abundance vs OS')
pdf('Stage12_results/ICGC_C3_KM_OS.pdf', width = 6, height = 6); print(p); dev.off()

# 10. C3 relative fraction within C1-C4 (original sensitivity analysis)
# Tumor_Purity here means the sum of estimated C1-C4 fractions, NOT histologic purity.
# This is not a causal adjustment for tumor purity.
tumor_clusters <- c('C1', 'C2', 'C3', 'C4')

tcga_purity <- data.frame(Sample = rownames(theta_tcga), C3_Absolute = theta_tcga[, 'C3'],
  Tumor_Purity = rowSums(theta_tcga[, tumor_clusters, drop = FALSE]))
tcga_purity$C3_Relative <- with(tcga_purity, ifelse(Tumor_Purity > 0, C3_Absolute / Tumor_Purity, NA_real_))
write.csv(tcga_purity, 'Stage12_results/C3_Purity_Adjusted_TCGA.csv', row.names = FALSE)

purity_14520 <- data.frame(Sample = rownames(theta_14520), C3_Absolute = theta_14520[, 'C3'],
  Tumor_Purity = rowSums(theta_14520[, tumor_clusters, drop = FALSE]))
purity_14520$C3_Relative <- with(purity_14520, ifelse(Tumor_Purity > 0, C3_Absolute / Tumor_Purity, NA_real_))
write.csv(purity_14520, 'Stage12_results/C3_Purity_Adjusted_GSE14520.csv', row.names = FALSE)

purity_116174 <- data.frame(Sample = rownames(theta_116174), C3_Absolute = theta_116174[, 'C3'],
  Tumor_Purity = rowSums(theta_116174[, tumor_clusters, drop = FALSE]))
purity_116174$C3_Relative <- with(purity_116174, ifelse(Tumor_Purity > 0, C3_Absolute / Tumor_Purity, NA_real_))
write.csv(purity_116174, 'Stage12_results/C3_Purity_Adjusted_GSE116174.csv', row.names = FALSE)

purity_icgc <- data.frame(Sample = rownames(theta_icgc), C3_Absolute = theta_icgc[, 'C3'],
  Tumor_Purity = rowSums(theta_icgc[, tumor_clusters, drop = FALSE]))
purity_icgc$C3_Relative <- with(purity_icgc, ifelse(Tumor_Purity > 0, C3_Absolute / Tumor_Purity, NA_real_))
write.csv(purity_icgc, 'Stage12_results/C3_Purity_Adjusted_ICGC.csv', row.names = FALSE)

# 11. TCGA sensitivity analysis: C3 relative-fraction KM and Cox
# The original also applied the same two analyses to the other three cohorts.
tcga_purity$ID <- substr(gsub('\\.', '-', tcga_purity$Sample), 1, 12)
tcga_rel <- merge(tcga_purity, cli_tcga, by = 'ID')
tcga_rel <- tcga_rel[complete.cases(tcga_rel[, c('OS.months','OS.status','C3_Relative','C3_Absolute','Tumor_Purity')]), ]
tcga_rel$C3_Rel_Group <- ifelse(tcga_rel$C3_Relative > median(tcga_rel$C3_Relative), 'High', 'Low')
fit <- survfit(Surv(OS.months, OS.status) ~ C3_Rel_Group, data = tcga_rel)
p <- ggsurvplot(fit, data = tcga_rel, pval = TRUE, risk.table = TRUE,
                palette = c('#E41A1C', '#377EB8'), title = 'TCGA: C3 relative fraction vs OS')
pdf('Stage12_results/TCGA_C3_Relative_KM.pdf', width = 6.5, height = 6.5); print(p); dev.off()
cox_tcga <- coxph(Surv(OS.months, OS.status) ~ C3_Absolute + Tumor_Purity, data = tcga_rel)
write.csv(as.data.frame(summary(cox_tcga)$coefficients), 'Stage12_results/TCGA_Cox_C3_Purity.csv')

# 12. GSE14520 sensitivity analysis
purity_14520$ID <- trimws(purity_14520$Sample)
x <- merge(purity_14520, cli_14520, by = 'ID')
x$C3_Rel_Group <- ifelse(x$C3_Relative > median(x$C3_Relative, na.rm = TRUE), 'High', 'Low')
fit <- survfit(Surv(as.numeric(OS.months), as.numeric(OS.status)) ~ C3_Rel_Group, data = x)
p <- ggsurvplot(fit, data = x, pval = TRUE, risk.table = TRUE,
                palette = c('#E41A1C', '#377EB8'), title = 'GSE14520: C3 relative fraction vs OS')
pdf('Stage12_results/GSE14520_C3_Relative_KM.pdf', width = 6, height = 6); print(p); dev.off()
cox_14520 <- coxph(Surv(as.numeric(OS.months), as.numeric(OS.status)) ~ C3_Absolute + Tumor_Purity, data = x)
write.csv(as.data.frame(summary(cox_14520)$coefficients), 'Stage12_results/GSE14520_Cox_C3_Purity.csv')

# 13. GSE116174 sensitivity analysis
purity_116174$ID <- trimws(purity_116174$Sample)
x <- merge(purity_116174, cli_116174, by = 'ID')
x$C3_Rel_Group <- ifelse(x$C3_Relative > median(x$C3_Relative, na.rm = TRUE), 'High', 'Low')
fit <- survfit(Surv(as.numeric(Follow_up.time.month.), as.numeric(Event_death)) ~ C3_Rel_Group, data = x)
p <- ggsurvplot(fit, data = x, pval = TRUE, risk.table = TRUE,
                palette = c('#E41A1C', '#377EB8'), title = 'GSE116174: C3 relative fraction vs OS')
pdf('Stage12_results/GSE116174_C3_Relative_KM.pdf', width = 6, height = 6); print(p); dev.off()
cox_116174 <- coxph(Surv(as.numeric(Follow_up.time.month.), as.numeric(Event_death)) ~ C3_Absolute + Tumor_Purity, data = x)
write.csv(as.data.frame(summary(cox_116174)$coefficients), 'Stage12_results/GSE116174_Cox_C3_Purity.csv')

# 14. ICGC sensitivity analysis
purity_icgc$ID <- trimws(purity_icgc$Sample)
x <- merge(purity_icgc, cli_icgc, by = 'ID')
x$C3_Rel_Group <- ifelse(x$C3_Relative > median(x$C3_Relative, na.rm = TRUE), 'High', 'Low')
fit <- survfit(Surv(as.numeric(OS.months), as.numeric(OS.status)) ~ C3_Rel_Group, data = x)
p <- ggsurvplot(fit, data = x, pval = TRUE, risk.table = TRUE,
                palette = c('#E41A1C', '#377EB8'), title = 'ICGC: C3 relative fraction vs OS')
pdf('Stage12_results/ICGC_C3_Relative_KM.pdf', width = 6, height = 6); print(p); dev.off()
cox_icgc <- coxph(Surv(as.numeric(OS.months), as.numeric(OS.status)) ~ C3_Absolute + Tumor_Purity, data = x)
write.csv(as.data.frame(summary(cox_icgc)$coefficients), 'Stage12_results/ICGC_Cox_C3_Purity.csv')

# No final-theta analyses are included: the original's final-theta section was
# exploratory and did not contain a complete reproducible downstream analysis.
