# -*- coding: utf-8 -*-
"""CytoTRACE2 differentiation-potential analysis of malignant cell subclusters."""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import scanpy as sc
from cytotrace2_py import cytotrace2

INPUT_FILE = Path('adata_Malcyto.h5ad')
OUTPUT_DIR = Path('cytotrace2_results')
CLUSTERS = ('C1', 'C2', 'C3', 'C4')
SCORE_COLUMNS = ('CytoTRACE2_Score', 'CytoTRACE2_Potency', 'CytoTRACE2_Relative')


def main():
    OUTPUT_DIR.mkdir(exist_ok=True)
    adata = sc.read_h5ad(INPUT_FILE)

    # The expression matrix must contain non-log-transformed expression values.
    expression = adata.X.toarray().T if hasattr(adata.X, 'toarray') else adata.X.T
    expression_file = OUTPUT_DIR / 'expression_matrix.txt'
    pd.DataFrame(expression, index=adata.var_names, columns=adata.obs_names).to_csv(
        expression_file, sep='\t'
    )

    annotation_file = OUTPUT_DIR / 'cell_annotations.txt'
    pd.DataFrame({
        'Cell_ID': adata.obs_names,
        'Cell_Type': adata.obs['cell_type_fine'].to_numpy(),
    }).to_csv(annotation_file, sep='\t', index=False)

    results = cytotrace2(
        input_path=str(expression_file),
        annotation_path=str(annotation_file),
        species='human',
        output_dir=str(OUTPUT_DIR),
        batch_size=10000,
        smooth_batch_size=1000,
        disable_parallelization=False,
        max_cores=4,
        disable_verbose=True,
        disable_plotting=False,
        seed=42,
    )

    # Match returned scores to cells by identifier, not by row position.
    if 'Cell_ID' in results.columns:
        results = results.set_index('Cell_ID')
    elif 'cell_id' in results.columns:
        results = results.set_index('cell_id')
    elif 'cell' in results.columns:
        results = results.set_index('cell')
    results.index = results.index.astype(str)
    if not adata.obs_names.isin(results.index).all():
        raise ValueError('CytoTRACE2 result cell IDs do not match the input AnnData.')
    for column in SCORE_COLUMNS:
        if column in results.columns:
            adata.obs[column] = results[column].reindex(adata.obs_names).to_numpy()

    results.to_csv(OUTPUT_DIR / 'cytotrace2_cell_results.csv')
    adata.write_h5ad(OUTPUT_DIR / 'adata_Mal_cytotrace2.h5ad')

    sc.pl.umap(adata, color='CytoTRACE2_Score', cmap='viridis', size=20,
               title='CytoTRACE2 Score', show=False)
    plt.savefig(OUTPUT_DIR / 'cytotrace2_umap.pdf', bbox_inches='tight')
    plt.close('all')

    selected = adata[adata.obs['cell_type_fine'].isin(CLUSTERS)].copy()
    sc.pl.violin(selected, keys='CytoTRACE2_Score', groupby='cell_type_fine',
                 order=list(CLUSTERS), stripplot=False, rotation=45, show=False)
    plt.savefig(OUTPUT_DIR / 'cytotrace2_by_cluster.pdf', bbox_inches='tight')
    plt.close('all')

    summary = selected.obs.groupby('cell_type_fine', observed=True)['CytoTRACE2_Score'].agg(
        ['count', 'mean', 'std', 'min', 'max']
    ).reindex(CLUSTERS)
    summary.to_csv(OUTPUT_DIR / 'cytotrace2_cluster_summary.csv')


if __name__ == '__main__':
    main()
