# -*- coding: utf-8 -*-
"""Stage 05: T-cell starCAT annotation and Fig. S7E–G.

Modes:
  default: extract T cells from stage 03, recompute T-cell UMAP and starCAT TCAT.V1.
  --historical-h5ad PATH: reuse saved adata_T.h5ad embeddings and labels for figures.

Historical Fig. S7 T-cell annotation uses starCAT ``Multinomial_Label``;
no final Leiden resolution can be established from the archived scripts.
Exploratory Leiden clustering is therefore NOT presented as a final annotation.
"""
import argparse
from pathlib import Path

import pandas as pd
import scanpy as sc

ROOT = Path(__file__).resolve().parent.parent
INPUT = ROOT / 'results' / '03_cell_type_annotation' / 'adata_annoed.h5ad'
OUTPUT = ROOT / 'results' / '05_tcell_starcat_annotation'
CACHE = ROOT / 'data' / 'reference_cache' / 'starcat'

T_MARKERS = {
    'Naive/Memory': ['IL7R', 'KLF2', 'SELL'],
    'Proliferating': ['MKI67', 'TOP2A'],
    'Early Effector': ['GZMK', 'CCL5'],
    'Terminal Effector': ['PRF1', 'ZEB2', 'GZMH', 'CX3CR1'],
    'Treg': ['FOXP3', 'CTLA4', 'IL2RA'],
    'Th1 Helper': ['IFNG', 'IL18R1'],
    'Costimulatory': ['CD40LG', 'TXNIP'],
}
STARCAT_PROGRAMS = [
    'CD4-Naive', 'CD8-Naive', 'Treg', 'Exhaustion', 'Th2-Activated',
    'Cytotoxic', 'TEMRA', 'CellCycle-S', 'Heatshock',
]


def calculate_tcell_umap(adata):
    """Recompute UMAP from scVI for the from-scratch path; no final Leiden claim."""
    if 'X_scVI' not in adata.obsm:
        raise KeyError('X_scVI missing: cannot calculate T-cell UMAP')
    sc.pp.neighbors(adata, use_rep='X_scVI', n_neighbors=15, random_state=2025)
    sc.tl.umap(adata, random_state=2025, min_dist=0.4)


def add_starcat_results(adata):
    """Predict TCAT.V1 states, preserving the source's raw-count input."""
    from starcat import starCAT

    if 'counts' not in adata.layers:
        raise KeyError("Expected original counts in adata.layers['counts']")
    CACHE.mkdir(parents=True, exist_ok=True)
    ct_input = adata.copy()
    ct_input.X = ct_input.layers['counts'].copy()
    reference = starCAT(reference='TCAT.V1', cachedir=str(CACHE))
    usage, scores = reference.fit_transform(ct_input)
    if not usage.index.is_unique or not scores.index.is_unique:
        raise ValueError('Duplicate cell IDs in starCAT output')
    if set(usage.index) != set(adata.obs_names) or set(scores.index) != set(adata.obs_names):
        raise ValueError('starCAT results do not contain exactly the input cell IDs')
    usage = usage.reindex(adata.obs_names)
    scores = scores.reindex(adata.obs_names)
    if usage.isna().all(axis=1).any() or scores.isna().all(axis=1).any():
        raise ValueError('Missing starCAT result rows')
    if 'Multinomial_Label' not in scores.columns:
        raise KeyError('starCAT output lacks Multinomial_Label')

    usage.to_csv(OUTPUT / 'starcat_usage.csv')
    scores.to_csv(OUTPUT / 'starcat_scores.csv')
    adata.obsm['X_starCAT_usage'] = usage.to_numpy()
    adata.uns['starCAT_usage_features'] = list(usage.columns)
    for col in scores.columns:
        adata.obs[f'starCAT_{col}'] = (
            scores[col].astype(str).to_numpy() if '_binary' in col else scores[col].to_numpy()
        )
    adata.obs['Multinomial_Label'] = scores['Multinomial_Label'].astype(str).to_numpy()
    adata.obs['starcat_label'] = adata.obs['Multinomial_Label'].copy()
    for col in usage.columns:
        if col not in adata.obs.columns:
            adata.obs[col] = usage[col].to_numpy()
    return adata


def prepare_historical_labels(adata):
    """Use existing starCAT labels; do not rerun clustering or overwrite UMAP."""
    if 'Multinomial_Label' not in adata.obs:
        if 'starcat_label' not in adata.obs:
            raise KeyError('Historical object lacks Multinomial_Label and starcat_label')
        adata.obs['Multinomial_Label'] = adata.obs['starcat_label'].astype(str)
    if 'starcat_label' in adata.obs:
        equal = (adata.obs['Multinomial_Label'].astype(str).to_numpy()
                 == adata.obs['starcat_label'].astype(str).to_numpy()).all()
        if not equal:
            raise ValueError('Historical Multinomial_Label and starcat_label disagree')
    else:
        adata.obs['starcat_label'] = adata.obs['Multinomial_Label'].astype(str)
    return adata


def export_tcell_figures(adata):
    """Fig. S7E: starCAT UMAP; S7F: markers; S7G: program UMAPs."""
    import matplotlib.pyplot as plt

    if 'X_umap' not in adata.obsm:
        raise KeyError('T-cell X_umap missing')
    fig_dir = OUTPUT / 'figures'
    fig_dir.mkdir(parents=True, exist_ok=True)
    plt.rcParams['pdf.fonttype'] = 42
    plt.rcParams['ps.fonttype'] = 42

    # Historical plot used color='Multinomial_Label', not leiden_0.5.
    fig = sc.pl.umap(
        adata, color='Multinomial_Label', legend_loc='right margin',
        frameon=False, show=False, return_fig=True,
    )
    fig.savefig(fig_dir / 'FigS7E_tcell_starcat_umap.pdf', dpi=300, bbox_inches='tight')
    plt.close(fig)

    if 'counts' not in adata.layers:
        raise KeyError("Marker DotPlot needs adata.layers['counts']")
    plot_data = adata.copy()
    plot_data.X = plot_data.layers['counts'].copy()
    sc.pp.normalize_total(plot_data, target_sum=1e4)
    sc.pp.log1p(plot_data)
    markers = {
        group: [g for g in genes if g in plot_data.var_names]
        for group, genes in T_MARKERS.items()
    }
    markers = {group: genes for group, genes in markers.items() if genes}
    if markers:
        dp = sc.pl.dotplot(
            plot_data, markers, groupby='Multinomial_Label',
            standard_scale='var', show=False, return_fig=True,
        )
        dp.savefig(fig_dir / 'FigS7F_tcell_markers.pdf')
        plt.close('all')

    # Programs must be numeric obs columns; use the original recorded values.
    programs = [
        p for p in STARCAT_PROGRAMS
        if p in adata.obs and pd.api.types.is_numeric_dtype(adata.obs[p])
    ]
    if programs:
        sc.pl.umap(adata, color=programs, ncols=3, vmin=0, vmax='p99', show=False)
        plt.savefig(fig_dir / 'FigS7G_tcell_starcat_programs.pdf',
                    dpi=300, bbox_inches='tight')
        plt.close('all')
    else:
        print('WARNING: No numeric starCAT program columns found; Fig. S7G not generated.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--historical-h5ad', type=Path, default=None,
                        help='Use saved adata_T.h5ad without recomputing UMAP/starCAT')
    args = parser.parse_args()
    OUTPUT.mkdir(parents=True, exist_ok=True)

    if args.historical_h5ad is not None:
        if not args.historical_h5ad.is_file():
            raise FileNotFoundError(args.historical_h5ad)
        adata_t = sc.read_h5ad(args.historical_h5ad)
        adata_t = prepare_historical_labels(adata_t)
        print('Historical figure mode: preserved original UMAP and starCAT labels.')
    else:
        if not INPUT.is_file():
            raise FileNotFoundError(INPUT)
        adata = sc.read_h5ad(INPUT)
        adata_t = adata[adata.obs['cell_type_coarse'] == 'T cell'].copy()
        calculate_tcell_umap(adata_t)
        adata_t = add_starcat_results(adata_t)
        print('Recomputed mode: UMAP and starCAT labels may differ from historical data.')

    adata_t.obs['Multinomial_Label'].value_counts().rename('n_cells').to_csv(
        OUTPUT / 'tcell_starcat_label_counts.csv', header=True,
    )
    export_tcell_figures(adata_t)
    # Never overwrite archived adata_T.h5ad.
    adata_t.write_h5ad(OUTPUT / 'adata_T_starcat.h5ad')
    print(f'Saved T-cell outputs to {OUTPUT}')


if __name__ == '__main__':
    main()
