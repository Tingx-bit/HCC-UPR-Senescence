"""InferCNV analysis of HCC single-cell transcriptomes."""
from pathlib import Path

import infercnvpy as cnv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import seaborn as sns
from scipy import sparse

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / 'adata_HCC_qc_lineage.h5ad'
ANNOTATION = ROOT / 'hg38.txt'
MALIGNANT = ROOT / 'adata_Malcyto.h5ad'
OUT = ROOT / '08_inferCNV_results'
OUT.mkdir(exist_ok=True)
REFERENCE = ['T cell', 'Myeloid cell', 'B cell', 'NK cell', 'Plasma cell']
CLUSTERS = ['C1', 'C2', 'C3', 'C4']


def main():
    adata = sc.read_h5ad(INPUT)
    coords = pd.read_csv(
        ANNOTATION, sep=r'\s+', header=None,
        names=['gene_symbol', 'chromosome', 'start', 'end'],
    ).drop_duplicates('gene_symbol').set_index('gene_symbol')
    adata.var = adata.var.drop(columns=['chromosome', 'start', 'end'], errors='ignore').join(
        coords[['chromosome', 'start', 'end']], how='left'
    )
    adata.var['start'] = pd.to_numeric(adata.var['start'], errors='coerce')
    adata.var['end'] = pd.to_numeric(adata.var['end'], errors='coerce')

    # Use the same immune-cell reference groups and window size as the original analysis.
    cnv.tl.infercnv(
        adata,
        reference_key='cell_type_fine',
        reference_cat=REFERENCE,
        window_size=250,
    )
    xcnv = adata.obsm['X_cnv']
    adata.obs['cnv_score'] = np.asarray(
        np.abs(xcnv).sum(axis=1) if sparse.issparse(xcnv) else np.abs(xcnv).sum(axis=1)
    ).ravel()

    # Transfer malignant subcluster labels by cell barcode, when the annotated object is available.
    if MALIGNANT.exists():
        mal = sc.read_h5ad(MALIGNANT, backed='r')
        labels = mal.obs['cell_type_fine'].astype(str)
        mal.file.close()
        adata.obs['malignant_subcluster'] = labels.reindex(adata.obs_names)
        malignant = adata.obs.loc[
            adata.obs['malignant_subcluster'].isin(CLUSTERS),
            ['malignant_subcluster', 'cnv_score']
        ].copy()
        malignant.to_csv(OUT / 'malignant_cell_cnv_scores.csv', index_label='cell_id')
        summary = malignant.groupby('malignant_subcluster')['cnv_score'].agg(
            ['count', 'mean', 'median', 'std']
        ).reindex(CLUSTERS)
        summary.to_csv(OUT / 'malignant_subcluster_cnv_summary.csv')
        if not malignant.empty:
            fig, ax = plt.subplots(figsize=(6.5, 5))
            sns.boxplot(
                data=malignant, x='malignant_subcluster', y='cnv_score',
                order=CLUSTERS, showfliers=False, color='#90A8BC', ax=ax
            )
            ax.set(xlabel='', ylabel='CNV score')
            sns.despine()
            fig.tight_layout()
            fig.savefig(OUT / 'malignant_subcluster_cnv_boxplot.pdf')
            plt.close(fig)

    cnv.pl.chromosome_heatmap(adata, groupby='cell_type_fine', show=False)
    plt.savefig(OUT / 'cnv_chromosome_heatmap.pdf', bbox_inches='tight')
    plt.close('all')

    cnv.tl.pca(adata)
    cnv.pp.neighbors(adata)
    cnv.tl.leiden(adata)
    cnv.pl.chromosome_heatmap(adata, groupby='cnv_leiden', dendrogram=True, show=False)
    plt.savefig(OUT / 'cnv_cluster_heatmap.pdf', bbox_inches='tight')
    plt.close('all')
    cnv.tl.umap(adata)
    cnv.pl.umap(adata, color='cnv_leiden', show=False)
    plt.savefig(OUT / 'cnv_umap.pdf', bbox_inches='tight')
    plt.close('all')

    adata.obs[['cell_type_fine', 'cnv_score']].to_csv(
        OUT / 'all_cell_cnv_scores.csv', index_label='cell_id'
    )
    adata.write_h5ad(OUT / 'adata_with_infercnv.h5ad')


if __name__ == '__main__':
    main()
